<?php
$serverName = "pinscher.eirsautomation.xyz";
$connectionOptions = array(
	"Database" => "contec-lga",
	"UID" => "contec-lga",
	"PWD" => "7t5diN#4"
);
//Establishes the connection
$db_handle = sqlsrv_connect($serverName, $connectionOptions);


if (!$db_handle) {
	echo 'Connection attempt failed.';
}

function lastInsertID($tablename, $fieldname)
{
	//gets the last inserted ID
	global $db_handle;
	$seqnextval =  "select last_value FROM ${tablename}_${fieldname}_seq";
	//$result = sqlsrv_query($db_handle, $seqnextval);
	$result = sqlsrv_query($db_handle, $seqnextval, array(), array("Scrollable" => SQLSRV_CURSOR_KEYSET));

	if (!$result) {
		echo "An error occured.\n";
		exit;
	}

	$seq_array = sqlsrv_fetch_array($result, 0, SQLSRV_FETCH_NUMERIC);
	$nextval = $seq_array[0];


	return $nextval;
}

$sector = isset($_POST['sector']) ? $_POST['sector'] : '';
$subsector = isset($_POST['subsector']) ? $_POST['subsector'] : '';
$mobile = isset($_POST['mobile']) ? $_POST['mobile'] : '';
$taxpayertype = isset($_POST['taxpayertype']) ? $_POST['taxpayertype'] : '';
$assetname = isset($_POST['assetname']) ? $_POST['assetname'] : '';
$assetnumber = isset($_POST['assetnumber']) ? $_POST['assetnumber'] : '';
$transactionRef = isset($_POST['transactionRef']) ? $_POST['transactionRef'] : '';
$scratchcard = isset($_POST['scratchcard']) ? $_POST['scratchcard'] : '';
$agentid = isset($_POST['agentid']) ? $_POST['agentid'] : '';
$payerid = isset($_POST['payerid']) ? $_POST['payerid'] : '';
$settlementid = "3";
$mobile = "234" . $mobile;
$canSync = isset($_POST['canSync']) ? $_POST['canSync'] : '2';
$transactionDone = isset($_POST['transactionDone']) ? $_POST['transactionDone'] : '2';
$invalidPins = isset($_POST['invalidPins']) ? $_POST['invalidPins'] : '2';
$taxpayerlga = isset($_POST['taxpayerlga']) ? $_POST['taxpayerlga'] : '';
$period = isset($_POST['period']) ? $_POST['period'] : '';
$offlineSavedAt = isset($_POST['offlineSavedAt']) ? $_POST['offlineSavedAt'] : '';

if ($taxpayertype == "1") {
	$taxpayer = "company";
} else if ($taxpayertype == "2") {
	$taxpayer = "individual";
}


if ($sector == "TRANSPORTATION") {
	$assettype = "2";
} else if ($sector != "TRANSPORTATION") {
	$assettype = "1";
}


//Code for Adding Transaction Details starts here
if ($assettype == "1") {
	$assetid = lastInsertID("businesses", "id");
	$assetval = "Business";
} else if ($assettype == "2") {
	$assetid = lastInsertID("vehicles", "id");
	$assetval = "vehicles";
}



$scratchcards = json_decode($scratchcard);

foreach ($scratchcards as $scratchcardval) {

	$cardno =  $scratchcardval->card;
	$cardamount =  $scratchcardval->amount;

	$addtransaction = "INSERT INTO transactions (taxpayerid,assetid,transactionid,created_at,updated_at,amount,scratchcard,settlementid, taxpayertype, assettype, sector, subsector, mobile, vehicleno, agent_id, period, lga, cansync , transactiondone ,invalidpins,offline_saved_at ) VALUES ('$payerid', '$assetid', '$transactionRef', current_timestamp,  current_timestamp, '$cardamount', '$cardno', '$settlementid', '$taxpayer', '$assetval', '$sector', '$subsector', '$mobile', '$assetnumber', '$agentid', '$period', '$taxpayerlga', '$canSync', '$transactionDone','$invalidPins','$offlineSavedAt')";

	//$result = sqlsrv_exec($db_handle, $addtransaction);
	$result = sqlsrv_query($db_handle, $addtransaction, array(), array("Scrollable" => SQLSRV_CURSOR_KEYSET));
}

//Code for Adding Transaction Details ends here	

$response = array(
	'status' => true,
	'status_message' => 'Transaction Added Successfully',
);

print_r(json_encode($response));
sqlsrv_close($db_handle);
