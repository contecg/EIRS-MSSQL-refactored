<?php
$date = date("Y-m-d");

$oneWeekAgo = strtotime('-1 week', strtotime($date));

$previousweek = date('Y-m-d G:i:s', $oneWeekAgo);


define('SECONDS_PER_DAY', 86400);



$serverName = "pinscher.eirsautomation.xyz";
$connectionOptions = array(
	"Database" => "contec-lga",
	"UID" => "contec-lga",
	"PWD" => "7t5diN#4"
);
//Establishes the connection
$db_handle = sqlsrv_connect($serverName, $connectionOptions);

$mobile = isset($_POST['mobileno']) ? $_POST['mobileno'] : '';
$vehicleno = isset($_POST['vehicleno']) ? $_POST['vehicleno'] : '';
$agentid = isset($_POST['agentid']) ? $_POST['agentid'] : '';
$scratchcard = isset($_POST['scratchcard']) ? $_POST['scratchcard'] : '';

$startdate = date('Y-m-d', time() - 3 * SECONDS_PER_DAY);

$enddate =  date('Y-m-d', time() + 1 * SECONDS_PER_DAY);

$get_collection = "";

if (empty($mobile) || empty($vehicleno) || empty($scratchcard)) {
	//echo "test";
	$get_collection =  "select * from transactions where (created_at >= '$previousweek') and (agent_id  = '$agentid') ";
	//$result = sqlsrv_exec($db_handle, $get_collection);
	$result = sqlsrv_query($db_handle, $get_collection, array(), array("Scrollable" => SQLSRV_CURSOR_KEYSET));
}



//exit();	



if (isset($_POST['mobileno'])) {
	//$mobile = "234".$mobile;
	//$_POST['mobileno'] =  strlen($_POST['mobileno']);
	$_POST['mobileno'] = substr($_POST['mobileno'], 1, -1);
	//echo $_POST['mobileno'];
	$mobile = $_POST['mobileno'];
	$get_collection =  "select * from transactions where (agent_id  = '$agentid') ";
	$get_collection .= " and mobile like '%$mobile%'";
	$result = sqlsrv_exec($db_handle, $get_collection);
} else if (isset($_POST['vehicleno'])) {
	$get_collection =  "select * from transactions where (agent_id  = '$agentid') ";
	$get_collection .= " and vehicleno = '$vehicleno'";
	$result = sqlsrv_exec($db_handle, $get_collection);
} else if (isset($_POST['scratchcard'])) {
	$get_collection =  "select * from transactions where (agent_id  = '$agentid') ";
	$get_collection .= " and scratchcard = '$scratchcard'";
	$result = sqlsrv_query($db_handle, $get_collection);
}

//echo $get_collection;


//exit();	

if (!$result) {
	echo "An error occured.\n";
	exit;
}
$info = array();
$array_out = array();
while ($ro = sqlsrv_fetch_object($result)) {

	$info['id'] =  $ro->id;
	$info['taxpayerid'] = $ro->taxpayerid;
	$info['assetid'] = $ro->assetid;
	$info['transactionid'] = $ro->transactionid;
	$info['created_at'] = date("d-m-Y H:m a", strtotime($ro->created_at));
	$info['updated_at'] = date("d-m-Y H:m a", strtotime($ro->updated_at));
	$info['amount'] = $ro->amount;
	$info['scratchcard'] = $ro->scratchcard;
	$info['agent_id'] = $ro->agent_id;
	$info['taxpayertype'] = $ro->taxpayertype;
	$info['assettype'] = $ro->assettype;
	$info['sector'] = $ro->sector;
	$info['subsector'] = $ro->subsector;
	$info['mobile'] = $ro->mobile;
	$info['vehicleno'] = $ro->vehicleno;
	$info['lga'] = $ro->lga;
	$info['period'] = $ro->period;
	$info['canSync'] = $ro->cansync;
	$info['transactionDone'] = $ro->transactiondone;
	$info['invalidPins'] = $ro->invalidpins;
	$array_out[] = $info;
}

print_r(json_encode($array_out));
sqlsrv_close($db_handle);

exit();
