<?php

$serverName = "pinscher.eirsautomation.xyz";
$connectionOptions = array(
	"Database" => "contec-lga",
	"UID" => "contec-lga",
	"PWD" => "7t5diN#4"
);
//Establishes the connection
$db_handle = sqlsrv_connect($serverName, $connectionOptions);


$tablename1 =  "taxpayer";
$tablename2 =  "vehicleslga";

$taxpayertype = isset($_POST['taxpayertype']) ? $_POST['taxpayertype'] : '';
$srchval = isset($_POST['srchval']) ? $_POST['srchval'] : '';

$respstat = false;
$vehicleexist = false;
$prefixval = "234";

$get_taxpayerinformation =  "select id, phone, address, name, lga, rin, uuid from $tablename1 where phone = '$prefixval $srchval' limit 1";


//echo $get_taxpayerinformation;
//$result = sqlsrv_exec($db_handle, $get_taxpayerinformation);
$result = sqlsrv_query($db_handle, $get_taxpayerinformation, array(), array("Scrollable" => SQLSRV_CURSOR_KEYSET));

if (!$result) {
	echo "An error occured.\n";
	exit;
}

$numrows = sqlsrv_num_rows($result);

if ($numrows > 0) {
	$respstat = true;
	$arr = sqlsrv_fetch_array($result, 0, SQLSRV_FETCH_NUMERIC);
	$id = $arr[0];
	$phone = $arr[1];
	$address = $arr[2];
	$name = $arr[3];
	$lga = $arr[4];
	$rin = $arr[5];
	$taxpayerid = $arr[6];

	$response = array(
		'status' => true,
		'status_message' => 'Tax Payer Details',
		'id' => $id,
		'phone' => $phone,
		'address' => $address,
		'taxpayername' => $name,
		'lga' => $lga,
		'rin' => $rin,
		'payerid' => $taxpayerid,
		'vehiclenumber' => '',
		'sector' => '',
		'subsector' => '',
		'isvehicle' => '0'
	);
	print_r(json_encode($response));
	sqlsrv_close($db_handle);
	exit();
} else {
	$respstat = false;
}

if ($respstat == false) {
	$get_vehicleinformation =  "select x.id as id, x.phone as phone, x.address as address, x.name as name, x.lga as lga, x.rin as rin, x.uuid as uuid, y.vehicle_number as vehicle_number, y.sector as sector, y.subsector as subsector  from $tablename1 as x, $tablename2 as y where x.uuid = y.uuid and vehicle_number = '$srchval' limit 1";

	//$resultvehicle = sqlsrv_exec($db_handle, $get_vehicleinformation);
	$resultvehicle = sqlsrv_query($db_handle, $get_vehicleinformation, array(), array("Scrollable" => SQLSRV_CURSOR_KEYSET));


	if (!$resultvehicle) {
		echo "An error occured.\n";
		exit;
	}

	$numrowsvehicle = sqlsrv_num_rows($resultvehicle);

	if ($numrowsvehicle > 0) {
		$vehicleexist = true;
		$arr = sqlsrv_fetch_array($resultvehicle, 0, SQLSRV_FETCH_NUMERIC);
		$id = $arr[0];
		$phone = $arr[1];
		$address = $arr[2];
		$name = $arr[3];
		$lga = $arr[4];
		$rin = $arr[5];
		$taxpayerid = $arr[6];
		$vehiclenumber = $arr[7];
		$sector = $arr[8];
		$subsector = $arr[9];


		$response = array(
			'status' => true,
			'status_message' => 'Tax Payer Details',
			'id' => $id,
			'phone' => $phone,
			'address' => $address,
			'taxpayername' => $name,
			'lga' => $lga,
			'rin' => $rin,
			'payerid' => $taxpayerid,
			'vehiclenumber' => $vehiclenumber,
			'sector' => $sector,
			'subsector' => $subsector,
			'isvehicle' => '1'
		);
	} else {
		$vehicleexist = false;
	}
}

if ($vehicleexist == false) {
	$response = array(
		'status' => false,
		'status_message' => 'No Records Found'
	);
}

print_r(json_encode($response));
sqlsrv_close($db_handle);

exit();
