<?php

$serverName = "pinscher.eirsautomation.xyz";
$connectionOptions = array(
	"Database" => "contec-lga",
	"UID" => "contec-lga",
	"PWD" => "7t5diN#4"
);
//Establishes the connection
$db_handle = sqlsrv_connect($serverName, $connectionOptions);


if (!$db_handle) {
	echo 'Connection attempt failed.';
}



function lastInsertID($tablename, $fieldname)
{
	//gets the last inserted ID
	global $db_handle;
	$seqnextval =  "select last_value FROM ${tablename}_${fieldname}_seq";
	//$result = sqlsrv_query($db_handle, $seqnextval);
	$result = sqlsrv_query($db_handle, $seqnextval, array(), array("Scrollable" => SQLSRV_CURSOR_KEYSET));

	if (!$result) {
		echo "An error occured.\n";
		exit;
	}

	$seq_array = sqlsrv_fetch_array($result, 0, SQLSRV_FETCH_NUMERIC);
	$nextval = $seq_array[0];


	return $nextval;
}


function randomString()
{
	$alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
	$pass = array(); //remember to declare $pass as an array
	$alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
	for ($i = 0; $i < 12; $i++) {
		$n = rand(0, $alphaLength);
		$pass[] = $alphabet[$n];
	}
	return $rand_pass = implode($pass);
}






$collamount = isset($_POST['amount']) ? $_POST['amount'] : '';
$taxpayertype = isset($_POST['taxpayertype']) ? $_POST['taxpayertype'] : '';
$sector = isset($_POST['sector']) ? $_POST['sector'] : '';
$subsector = isset($_POST['subsector']) ? $_POST['subsector'] : '';
$taxpayerrin = isset($_POST['taxpayerrin']) ? $_POST['taxpayerrin'] : '';
$taxpayername = isset($_POST['taxpayername']) ? $_POST['taxpayername'] : '';
$mobile = isset($_POST['mobile']) ? $_POST['mobile'] : '';
$address = isset($_POST['address']) ? $_POST['address'] : '';
$taxpayerlga = isset($_POST['taxpayerlga']) ? $_POST['taxpayerlga'] : '';
$assetname = isset($_POST['assetname']) ? $_POST['assetname'] : '';
$address = isset($_POST['address']) ? $_POST['address'] : '';
$period = isset($_POST['period']) ? $_POST['period'] : '';
$assetlga = isset($_POST['taxpayerlga']) ? $_POST['taxpayerlga'] : '';
$assetnumber = isset($_POST['assetnumber']) ? $_POST['assetnumber'] : '';
$onlinecapture = isset($_POST['onlinecapture']) ? $_POST['onlinecapture'] : '';
$transactionRef = isset($_POST['transactionRef']) ? $_POST['transactionRef'] : '';
$scratchcard = isset($_POST['scratchcard']) ? $_POST['scratchcard'] : '';
$agentid = isset($_POST['agentid']) ? $_POST['agentid'] : '';
$settlementid = "3";

$uuid = randomString();

if ($taxpayertype == "1") {
	$taxpayer = "company";
} else if ($taxpayertype == "2") {
	$taxpayer = "individual";
}

$mobile = "234" . $mobile;
$query = "INSERT INTO taxpayer (phone,address,created_at,updated_at,amount,name,lga,rin, uuid, taxpayertype, onlinecapture) VALUES ('$mobile','$address',  current_timestamp,  current_timestamp,'$collamount','$taxpayername', '$taxpayerlga', '$taxpayerrin', '$uuid', '$taxpayer', '$onlinecapture')";


//$result = sqlsrv_exec($db_handle, $query);
$result = sqlsrv_query($db_handle, $query, array(), array("Scrollable" => SQLSRV_CURSOR_KEYSET));

if ($sector == "TRANSPORTATION") {
	$assettype = "2";
} else if ($sector != "TRANSPORTATION") {
	$assettype = "1";
}


if ($result) {
	$taxpayerid = lastInsertID("taxpayer", "id");





	if ($assettype == "1") {

		if ($onlinecapture == 'Y') {
			$query = "INSERT INTO businesseslga (name,address,lga,individual_id,created_at,updated_at,amount,uuid, sector, subsector, taxpayer, onlinecapture) VALUES ('$assetname', '$address', '$assetlga', '$taxpayerid', current_timestamp,  current_timestamp, '$collamount','$uuid', '$sector', '$subsector', '$taxpayer', '$onlinecapture')";
		} else {
			$query = "INSERT INTO businesseslga (name,address,lga,individual_id,created_at,updated_at,amount,uuid, sector, subsector, taxpayer, onlinecapture, syncedonline) VALUES ('$assetname', '$address', '$assetlga', '$taxpayerid', current_timestamp,  current_timestamp, '$collamount','$uuid', '$sector', '$subsector', '$taxpayer', '$onlinecapture', current_timestamp)";
		}

		//$result = sqlsrv_exec($db_handle, $query);
		$result = sqlsrv_query($db_handle, $query, array(), array("Scrollable" => SQLSRV_CURSOR_KEYSET));
	} else if ($assettype == "2") {

		if ($onlinecapture == 'Y') {
			$query = "INSERT INTO vehicleslga (vehicle_number,lga,individual_id,created_at,updated_at,amount,uuid, sector, subsector, taxpayer, onlinecapture) VALUES ('$assetnumber', '$assetlga', '$taxpayerid', current_timestamp,  current_timestamp, '$collamount', '$uuid', '$sector', '$subsector', '$taxpayer', '$onlinecapture')";
		} else if ($onlinecapture == 'N') {
			$query = "INSERT INTO vehicleslga (vehicle_number,lga,individual_id,created_at,updated_at,amount,uuid, sector, subsector, taxpayer, onlinecapture, syncedonline) VALUES ('$assetnumber', '$assetlga', '$taxpayerid', current_timestamp,  current_timestamp, '$collamount', '$uuid', '$sector', '$subsector', '$taxpayer', '$onlinecapture', current_timestamp)";
		}


		//$result = sqlsrv_exec($db_handle, $query);
		$result = sqlsrv_query($db_handle, $query, array(), array("Scrollable" => SQLSRV_CURSOR_KEYSET));
	}



	$response = array(
		'status' => true,
		'status_message' => 'Tax Payer and Asset Added Successfully',
		'payerid' => $uuid
	);
} else {
	echo "There was an error! " . sqlsrv_errors();
}




print_r(json_encode($response));
sqlsrv_close($db_handle);
