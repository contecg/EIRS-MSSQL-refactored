<?php

$serverName = "pinscher.eirsautomation.xyz";
$connectionOptions = array(
	"Database" => "contec-lga",
	"UID" => "contec-lga",
	"PWD" => "7t5diN#4"
);
//Establishes the connection
$db_handle = sqlsrv_connect($serverName, $connectionOptions);


$respstat = false;
$response = array();

$get_bearertoken =  "select bearertoken from apitoken";

$result = sqlsrv_query($db_handle, $get_bearertoken, array(), array("Scrollable" => SQLSRV_CURSOR_KEYSET));

if (!$result) {
	echo "An error occured.\n";
	exit;
}


$numrows = sqlsrv_num_rows($result);

if ($numrows > 0) {
	$ro = sqlsrv_fetch_object($result);
	$bearertoken = $ro->bearertoken;
	$respstat = true;
} else {

	$respstat = false;
}

if ($respstat == true) {
	$response = array(
		'status' => 1,
		'bearertoken' => $bearertoken
	);
} else if ($respstat == false) {
	$response = array(
		'status' => 0,
		'bearertoken' => ''
	);
}




print_r(json_encode($response));
sqlsrv_close($db_handle);

exit();
