<?php
$serverName = "pinscher.eirsautomation.xyz";
$connectionOptions = array(
	"Database" => "contec-lga",
	"UID" => "contec-lga",
	"PWD" => "7t5diN#4"
);
//Establishes the connection
$db_handle = sqlsrv_connect($serverName, $connectionOptions);	

if (!$db_handle) {   
    echo 'Connection attempt failed.';   
	} 

if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
    throw new Exception('Request method must be POST!');
}
$contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';
if(strcasecmp($contentType, 'application/json') != 0){
    throw new Exception('Content type must be: application/json');
}
 
//$content = trim(file_get_contents("php://input"));
$offlinetransactions = json_decode(file_get_contents("php://input"), true);
//print_r($offlinetransactions);
if(!is_array($offlinetransactions)){
    throw new Exception('Received content contained invalid JSON!');
}	
		
		
		for($i=0;$i<count($offlinetransactions );){				
				$address =  $offlinetransactions[$i] ['address'];
				
				$amount =  $offlinetransactions[$i] ['amount'];
				$assettype =  $offlinetransactions[$i] ['assetType'];
				$assetlga =  $offlinetransactions[$i] ['assetlga'];
				$assetname =  $offlinetransactions[$i] ['assetname'];
				$assetnumber =  $offlinetransactions[$i] ['assetnumber'];
				$cansync =  $offlinetransactions[$i] ['canSync'];
				$mobile =  $offlinetransactions[$i] ['mobile'];
				$payerId =  isset($offlinetransactions[$i] ['payerID']) ? $offlinetransactions[$i] ['payerID'] : '';
				$period =  $offlinetransactions[$i] ['period'];
				$registeredlater =  $offlinetransactions[$i] ['registeredLater'];
				$registeredOnServer =  $offlinetransactions[$i] ['registeredOnServer'];
				$scratchpins =  $offlinetransactions[$i] ['scratchpins'];
				$sector =  $offlinetransactions[$i] ['sector'];
				$subsector =  $offlinetransactions[$i] ['subsector'];
				$taxpayerlga =  $offlinetransactions [$i]['taxpayerlga'];
				$taxpayername =  $offlinetransactions[$i] ['taxpayername'];
				$taxpayerrin =  $offlinetransactions[$i] ['taxpayerrin'];
				$taxpayertype =  $offlinetransactions [$i]['taxpayertype'];
				$transactionDone =  $offlinetransactions[$i] ['transactionDone'];
				$transactionId =  $offlinetransactions[$i] ['transactionId'];
				$agent_Id =  $offlinetransactions [$i]['agent_id'];
				$agent_phone =  $offlinetransactions [$i]['agent_phone'];
				$idno =  $offlinetransactions[$i] ['id'];
				$invalidpins =  $offlinetransactions[$i] ['invalidPins'];
				$transactionRef  =  isset($offlinetransactions[$i] ['transactionRef']) ? $offlinetransactions[$i] ['transactionRef'] : '';
				 
				
				$get_status =  "select * from offlinetransactions where (transactionId = '$transactionId') and (agent_id = '$agent_Id')";
				
				//$resultsatus = sqlsrv_exec($db_handle, $get_status);
				$result = sqlsrv_query($db_handle, $get_status, array(), array("Scrollable" => SQLSRV_CURSOR_KEYSET));
				
				if (!$resultsatus) 
				{
					echo "An error occured.\n";
					exit;
				}
				
				$numrows = sqlsrv_num_rows($resultsatus);
				
				if (!$numrows > 0)
				{
				
				$addtransaction = "INSERT INTO offlinetransactions (address,amount, assettype, assetlga, assetname, assetnumber, cansync, mobile, payerId, period, registeredlater, registeredOnServer,scratchpins, sector, subsector, taxpayerlga, taxpayername, taxpayerrin, taxpayertype, transactionDone, transactionId, agent_Id, agent_phone, idno, invalidpins,transactionRef) VALUES ('$address','$amount', '$assettype', '$assetlga', '$assetname', '$assetnumber', '$cansync', '$mobile', '$payerId', '$period', '$registeredlater', '$registeredOnServer', '$scratchpins', '$sector', '$subsector', '$taxpayerlga', '$taxpayername', '$taxpayerrin', '$taxpayertype', '$transactionDone', '$transactionId', '$agent_Id', '$agent_phone', '$idno', '$invalidpins', '$transactionRef')";
	
				$result = sqlsrv_exec($db_handle, $addtransaction);
				}
$i=$i+1;
		
		}
		
	$response=array(
                     'status' => true,
                     'status_message' =>'Offline Transactions Added Successfully',
					);
	
	print_r(json_encode($response));
	sqlsrv_close($db_handle);
