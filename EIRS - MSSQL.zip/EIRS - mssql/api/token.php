<?php

$serverName = "pinscher.eirsautomation.xyz";
$connectionOptions = array(
  "Database" => "contec-lga",
  "UID" => "contec-lga",
  "PWD" => "7t5diN#4"
);
//Establishes the connection
$db_handle = sqlsrv_connect($serverName, $connectionOptions);



if (!$db_handle) {
  echo 'Connection attempt failed.';
} else {
  echo 'successful connection! ';
}



$curl = curl_init();
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt_array($curl, array(
  CURLOPT_URL => "https://mas.eirs.gov.ng/apiv1/auth/login",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => "------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"userName\"\r\n\r\ncontecLP\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"password\"\r\n\r\nmD74fw5^f9k&?U5A\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--",
  CURLOPT_HTTPHEADER => array(
    "Postman-Token: e8703cdf-d367-443b-9a95-272d54934cc5",
    "cache-control: no-cache",
    "content-type: multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  ($response);
}

echo $response;


$json = json_decode($response, true);
$rdata = json_decode($response, true);

foreach ($rdata as $data) {

  $bearertoken = $rdata['token']; //echo $bearertoken; exit;
  $expiry = $rdata['expiry'];
  //count tables
  $query1 = "select * from apitoken";
  //$result1 = sqlsrv_query($db_handle, $query1);
  $result = sqlsrv_query($db_handle, $query1, array(), array("Scrollable" => SQLSRV_CURSOR_KEYSET));
  $numrows = sqlsrv_num_rows($result1);
  //echo $numrows . " row(s) returned.\n"; 
  if ($numrows >= 0) {
    // count <1 then delete data from table
    $query1 = "delete from apitoken";
    //$result = sqlsrv_query($db_handle, $query1);
    $result = sqlsrv_query($db_handle, $query1, array(), array("Scrollable" => SQLSRV_CURSOR_KEYSET));
    // then insert new data
    $query = "INSERT INTO apitoken (bearertoken,expiry,created_at ) VALUES ('$bearertoken' , '$expiry', current_timestamp)";

    //$result = sqlsrv_exec($db_handle, $query);
    $result = sqlsrv_query($db_handle, $query, array(), array("Scrollable" => SQLSRV_CURSOR_KEYSET));
  }
}
