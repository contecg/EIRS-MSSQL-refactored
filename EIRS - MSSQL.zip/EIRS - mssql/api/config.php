<?php

$response=array(
	"fetchScratchCardInterval"=>1000*60*60*24*7,
	"enableDeletion"=>false,
	"dailyFetchInterval"=>1000*60*60*24

);
echo json_encode($response);

?>