<?php

$serverName = "pinscher.eirsautomation.xyz";
$connectionOptions = array(
	"Database" => "contec-lga",
	"UID" => "contec-lga",
	"PWD" => "7t5diN#4"
);
//Establishes the connection
$db_handle = sqlsrv_connect($serverName, $connectionOptions);


$mobile = isset($_POST['mobileno']) ? $_POST['mobileno'] : '';
$respstat = false;
$response = array();
if (isset($_POST['mobileno'])) {

	$_POST['mobileno'] = substr($_POST['mobileno'], -10);
	$mobile = $_POST['mobileno'];
	$get_status =  "select status from agents where (phone like '%$mobile')";

	//echo $get_status;	

	//$result = sqlsrv_exec($db_handle, $get_status);
	$result = sqlsrv_query($db_handle, $get_status, array(), array("Scrollable" => SQLSRV_CURSOR_KEYSET));

	if (!$result) {
		echo "An error occured.\n";
		exit;
	}

	$numrows = sqlsrv_num_rows($result);

	if ($numrows > 0) {
		$ro = sqlsrv_fetch_object($result);
		$logstatus = $ro->status;

		if ($logstatus == 'D') {

			$respstat = true;
		} else if ($logstatus == 'A') {

			$respstat = false;
		}
	}

	if ($respstat == true) {
		$response = array(
			'status' => 0,
			'status_message' => 'LGA Agent is Blocked'
		);
	} else if ($respstat == false) {
		$response = array(
			'status' => 1,
			'status_message' => 'LGA Agent is Not Blocked'
		);
	}
}

print_r(json_encode($response));
sqlsrv_close($db_handle);

exit();
