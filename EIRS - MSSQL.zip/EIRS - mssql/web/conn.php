<?php 
	$serverName = "pinscher.eirsautomation.xyz";
    $connectionOptions = array(
        "Database" => "contec-lga",
        "UID" => "contec-lga",
        "PWD" => "7t5diN#4"
    );
    //Establishes the connection
    global $conn;
    $conn = sqlsrv_connect($serverName, $connectionOptions);
?>

