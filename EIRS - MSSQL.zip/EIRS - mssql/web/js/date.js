<script src="bower_components/jquery/dist/jquery.min.js"></script>

<script>
					$(function() {
					$('input[name="daterange"]').daterangepicker({
						opens: 'right'
					}, function(start, end, label) {
						console.log("A new date selection was made: " + start.format('DD-MM-YYYY') + ' to ' + end.format('DD-MM-YYYY'));
					});
					});
				</script>