<?php
include_once('head.php');
include_once('navbar.php');

?>

<!----------main content--------->
<div class="navbar navbar-custom" rol="navigation">

	<div class="container">
		<div><strong>
				<h2 style="color: grey;"><?php echo ucfirst($_GET['controller']); ?></h2>
			</strong></div>
	</div>

</div>

<section>


	<div>

		<form action="<?= $_SERVER['PHP_SELF']; ?>?controller=taxpayers" method="POST" class="container">
			<div class="col-sm-2 title" style="font-size: 13px;">
				<b>Payer Type:</b> <select name="payertype" id="time" style="width: 120px; height: 35px; border: 1px solid #ecf0f5; margin-right: 30px; border-radius: 3px;">
					<option value="" disabled selected>Please Select</option>
					<?php
					$res = sqlsrv_query($conn, "SELECT distinct taxpayertype as payertype FROM taxpayer ORDER BY taxpayertype ASC");
					while ($state_sel = sqlsrv_fetch_array($res)) {
						?>
						<option value="<?php echo $state_sel['payertype']; ?>"><?php echo ucfirst($state_sel['payertype']); ?></option>
					<?php } ?>
				</select>
			</div>
			<?php if ($_SESSION['lga'] == "") { ?>
				<div class="col-sm-2 title" style="font-size: 13px;">
					<b style="padding-right: 20px;">LGA List:</b> <select name="lga" id="time" style="width: 120px; height: 35px; border: 1px solid #ecf0f5; margin-right: 30px; border-radius: 3px;">
						<option value="" disabled selected>All LGA</option>
						<?php
						$res = sqlsrv_query($conn, "SELECT distinct lga as lga FROM taxpayer ORDER BY lga ASC");
						while ($state_sel = sqlsrv_fetch_array($res)) { ?>
							<option value="<?php echo $state_sel['lga']; ?>">
								<?php echo $state_sel['lga']; ?></option>
						<?php } ?>
					</select>
				</div>
			<?php } ?>
			<br>
			<div class="col-sm-2">
				<input class="btn btn-default bg-olive" type="submit" name="submit" value="Filter" style="width: 80px; height: 35px; border-radius: 3px; font-size: 13px;">
			</div>

			<?php

			if (isset($_GET['lga'])) {
				$lga = $_GET['lga'];
				$op = 'and';
			} else {
				$lga = 'Oredo';
				$op = 'or';
			}

			?>



	</div>
</section>
<!-- Main content -->
<section class="content">
	<div class="row">
		<div class="col-xs-12">
			<div class="box">

				<!----- Table head ------>

				<div class="row">
					<div class="col-md-12">
						<div class="box">
							<div class="box-header with-border">

								<div class="tab-pane active" id="list">
									<br />

								</div>

								<!-- /.box-header -->
								<div class="box-body">

									<?php

									$limit = 20;
									if (isset($_GET['page'])) {
										$page = $_GET["page"];
									} else {
										$page = 1;
									}
									$start_from = ($page - 1) * $limit;

									?>

									<div class="table-responsive">
										<?php
										//print_r($result);
										if (empty($users)) {
											echo "<div class='alert alert-warning' style='font-size: 12px';>No Records Found.</div>";
										} else { ?>
											<table class="table table-striped table-bordered table-responsive tablesorter" style="font-family: Arial; font-size: 12px; background:#a1d3a1; text-align:center;">
												<thead style="background: #779c77;">
													<tr>
														<th style="text-align:center;">Payer Id</th>
														<th style="text-align:center;">Phone</th>
														<th style="text-align:center;">LGA</th>
														<th style="text-align:center;">Creation Date</th>
														<th style="text-align:center;">Taxpayer Type</th>
														<th style="text-align:center;">Captured Online</th>
														<th style="text-align:center;">Details</th>
													</tr>
												</thead>
												<tbody>
													<?php while ($user = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {



														?>
														<tr>
															<td><?php print_r($user['uuid']); ?></td>
															<td><?php print_r($user['phone']); ?></td>
															<td><?php print_r($user['lga']); ?></td>
															<td><?php print_r($user['created_at']); ?></td>
															<td><?php print_r(ucfirst($user['taxpayertype'])); ?></td>
															<td><?php if ($user['onlinecapture'] == 'Y') {
																	print_r("<img src=\"images/online.png\" style=\"width:25px;height:25px;\"></img>");
																} else {
																	print_r("<img src=\"images/offline.png\" style=\"width:25px;height:25px;\"></img>");
																}
																?></td>

															<td><a href="index.php?controller=taxpayers&edit=<?php print_r($user['id']); ?> "><span class="glyphicon glyphicon-edit"></span> View More</a></td>
														</tr>

													<?php } ?>

												</tbody>
											</table>
										</div>

										<div class="paging">
											<div class="container">
												<div class="row">
													<div class="col-md-12">
														<?php
														$page = @$_GET['page'];
														if ($page == 0 || $page == 1) {
															@$page = 0;
														} else {
															$page1 = ($page * 4) - 4;
														}
														?>

													</div>

													<ul class="pagination">

														<?php
														$links = 5;
														$sql = substr($sql, 0, -40);
														$query = sqlsrv_query($conn, $sql, array(), array("Scrollable" => SQLSRV_CURSOR_KEYSET));
														$count = sqlsrv_num_rows($query);
														$last = ceil($count / $limit);
														$start = (($page - $links) > 0) ? $page - $links : 1;
														$end = (($page + $links) < $last) ? $page + $links : $last;

														$class = ($page == 1) ? "disabled" : "";

														$previous_page = ($page > 1) ?
															'<li class="' . $class . '"><a href="index.php?controller=taxpayers&page=' . ($page - 1) . '">&laquo;</a></li>' : '<li class="disabled"><a href="">&laquo;</a></li>';
														echo $previous_page;

														if ($start > 1) {
															echo '<li><a href="index.php?controller=taxpayers&page=' . 1 . '">' . 1 . '</a></li>';
															echo '<li class="disabled"><span>...</span></li>';
														}

														for ($i = $start; $i <= $end; $i++) {
															$class = ($page == $i) ? "active" : "";
															echo '<li class="' . $class . '"><a href="index.php?controller=taxpayers&page=' . $i . '">' . $i . '</a></li>';
														}


														if ($end < $last) {
															echo '<li class="disabled"><span>...</span></li>';
															echo '<li><a href="index.php?controller=taxpayers&page=' . $last . '">' . $last . '</a></li>';
														}

														$next_page = ($page == $last) ?
															'<li class="disabled"><a href="">&raquo;</a></li>' : '<li class="' . $class . '"><a href="index.php?controller=taxpayers&page=' . ($page + 1) . '">&raquo;</a></li>';
														echo $next_page;
														?>
														<br><br><br>

														<button class="btn btn-default" type="submit" value="Print" formaction="<?= $_SERVER['PHP_SELF']; ?>?controller=collectors" style="color: red; font-size: 12px; height: 35px; width: 37px;" onclick="window.print()"><span class="glyphicon glyphicon-print"></span></button>
														<button class="btn btn-default" type="submit" id="filter" name="filter" value="Download" formaction="models/taxpayers-excel.php" style="color: red; font-size: 12px; height: 35px; width: 37px;"><span class="glyphicon glyphicon-download-alt"></span></button>
														</form>
													</ul>
												</div>
											<?php

										} ?>
										</div>
</section>


<?php
include_once('footer.php');
?>