<footer>
        <div class="container">
            <div class="row">
                <div class="col-sm-1">
                    <div class="navbar-brand">
                       <!-- <img src="images/Logo.png" /> -->
                    </div>
                </div>
                <div class="col-sm-7" style="margin-left: 203px;">
                    &copy; Copyright EIRS - Edo State Internal Revenue Service 2018. All rights reserved
                </div>
              <!--  <div class="col-sm-4">
                    <ul>
                        <li>
                            <a href="#">Data Protection</a>
                        </li>
                        <li>
                            <a href="#">Terms of Use</a>
                        </li>
                        <li>
                            <a href="#">Contact Us</a>
                        </li>
                    </ul>
                </div> -->
            </div>
        </div>
    </footer>
   <script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.validate.min.js"></script>
<script type="text/javascript" src="js/jquery.unobtrusive-ajax.min.js"></script>
<script type="text/javascript" src="js/jquery.validate.unobtrusive.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="js/jsCommon.js"></script>



    
</body>
</html>