<?php 
include_once('head.php');
include_once('navbar.php');


?>
<script>
$(document).ready(function(){
  
});


</script>
 <!-- edit Section -->
<section id="page_add" class="page_add">
        <div class="content">
            <div class="row">
                <div class="col-lg-12">
                 <h2>New Collector</h2>
		<hr>
		
		<?php if (isset($msg)) { ?>
		<div <?php echo $class_stat; ?> role="alert"><?php echo $msg; ?><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button></div>
	<?php 
} ?>

		<form role="form" action="index.php?controller=add_collector&add" method="POST">

  					<div class="form-group" style="font-size: 13px;">
    						<label for="phone">Phone<abbr title="required" style="color: red;">*</abbr></label><br>
    						<input type="phone" name="phone" class="form-control" id="exampleInputtxt1"  style="font-size: 12px;" placeholder="Phone">
  					</div>
  					<div class="form-group" style="font-size: 13px;">
					          
    						<label for="exampleInputtxt1">First Name<abbr title="required" style="color: red;">*</abbr></label>
    						<input type="text" name="firstname" class="form-control" id="exampleInputtxt1"  style="font-size: 12px;" placeholder="First Name" onkeypress="return event.charCode >= 48 && event.charCode <= 57 || event.charCode >= 97 && event.charCode <= 122 || event.charCode >= 65 && event.charCode <= 90 || event.charCode == 32" required minlength="2"  maxlength="15" >
  					</div>
  					<div class="form-group" style="font-size: 13px;">
    						<label for="exampleInputtxt1">Last Name<abbr title="required" style="color: red;">*</abbr></label>
    						<input type="text" name="lastname" class="form-control" id="exampleInputtxt1" style="font-size: 12px;" placeholder="Last Name" onkeypress="return event.charCode >= 48 && event.charCode <= 57 || event.charCode >= 97 && event.charCode <= 122 || event.charCode >= 65 && event.charCode <= 90 || event.charCode == 32" required minlength="2"  maxlength="15">
  					</div>
  					<div class="form-group" style="font-size: 13px;">
    						<label for="exampleInputtxt1">Address</label>
    						<input type="text" name="address" class="form-control" id="exampleInputtxt1" style="font-size: 12px;" placeholder="Address">
  					</div>
  					<div class="form-group" style="font-size: 13px;">
    						<label for="exampleInputtxt1">Birthplace</label>
    						<input type="text" name="birthplace" class="form-control" style="font-size: 12px;" placeholder="Birthplace">
  					</div>
  					<div class="form-group" style="font-size: 13px;">
    						<label for="exampleInputtxt1">State</label><br>
    						<select name="state" id="state" style="width: 150px; font-size: 12px;">
								<option value="" disabled selected>Please Select</option>
								<option value="Abia">Abia</option>
								<option value="Adamawa">Adamawa</option>
								<option value="Akwa Ibom">Akwa Ibom</option>
								<option value="Anambra">Anambra</option>
								<option value="Bauchi">Bauchi</option>
								<option value="Bayelsa">Bayelsa</option>
								<option value="Benue">Benue</option>
								<option value="Borno">Borno</option>
								<option value="Cross River">Cross River</option>
								<option value="Delta">Delta</option>
								<option value="Ebonyi">Ebonyi</option>
								<option value="Enugu">Enugu</option>
								<option value="Edo" selected>Edo</option>
								<option value="Ekiti">Ekiti</option>
								<option value="FCT">FCT</option>
								<option value="Gombe">Gombe</option>
								<option value="Imo">Imo</option>
								<option value="Jigawa">Jigawa</option>
								<option value="Kaduna">Kaduna</option>
								<option value="Kano">Kano</option>
								<option value="Katsina">Katsina</option>
								<option value="Kebbi">Kebbi</option>
								<option value="Kogi">Kogi</option>
								<option value="Kwara">Kwara</option>
								<option value="Lagos">Lagos</option>
								<option value="Nasarawa">Nasarawa</option>
								<option value="Niger">Niger</option>
								<option value="Ogun">Ogun</option>
								<option value="Ondo">Ondo</option>
								<option value="Osun">Osun</option>
								<option value="Oyo">Oyo</option>
								<option value="Plateau">Plateau</option>
								<option value="Rivers">Rivers</option>
								<option value="Sokoto">Sokoto</option>
								<option value="Taraba">Taraba</option>
								<option value="Yobe">Yobe</option>
								<option value="Zamfara">Zamfara</option>
							</select>
  						</div>
					  
							<div class="form-group" style="font-size: 13px; width: 150px;">
								<label for="agent_beat_code">LGA<abbr title="required" style="color: red;">*</abbr></label><br>
								<select name="lga" id="agent_lga" class="lga" style="width: 150px; font-size: 12px;">
									
							<option value="" disabled selected>All LGA</option>
                            <option value="Akoko-Edo">Akoko-Edo</option>          									
                            <option value="Egor">Egor</option>          									
                            <option value="Esan Central">Esan Central</option>          									
                            <option value="Esan North-East">Esan North-East</option>          									
                            <option value="Esan South-East">Esan South-East</option>          									
                            <option value="Esan West">Esan West</option>          									
                            <option value="Etsako Central">Etsako Central</option>          									
                            <option value="Etsako East">Etsako East</option>          									
                            <option value="Etsako West">Etsako West</option>          									
                            <option value="Igueben">Igueben</option>          									
                            <option value="Ikpoba-Okha">Ikpoba-Okha</option>          									
                            <option value="Oredo">Oredo</option>          									
                            <option value="Orhionmwon">Orhionmwon</option>          									
                            <option value="Ovia North-East">Ovia North-East</option>          									
                            <option value="Ovia South-West">Ovia South-West</option>          									
                            <option value="Owan East">Owan East</option>          									
                            <option value="Owan West">Owan West</option>          									
                            <option value="Uhunmwonde">Uhunmwonde</option>          									
									
								</select>

							</div>

							<?php $beatsfile = realpath($_SERVER['DOCUMENT_ROOT'])."\web\js\beats.json"; 
							//echo $beatsfile;

						function current_url()
						{
							$url = "http://" . $_SERVER['HTTP_HOST'] . "/web/js/beat_data.json";
							$validURL = str_replace("&", "&amp", $url);
							return $validURL;
						}
						$offer_url = current_url();
						//echo $offer_url;	
							?>

							<div class="form-group" style="font-size: 13px; width: 150px;">
							<label for="agent_beat_code">Revenue Beats<abbr title="required" style="color: red;">*</abbr></label><br>
							<select name="revenuebeat" id="agent_beat_code" class="beat_code" style="width: 150px; font-size: 12px;">
								<option value="" style="font-size: 13px;">Please Select</option>
								</select>
								</div>

								<script type="text/javascript">
								var beat_json;


                                   $.getJSON("<?php echo $offer_url;?>", function(data) {
                                        beat_json = data;

                                    $(document).on('change',".lga",function(){
                                        var lga  = this.value;
                                        var lga_beats = beat_json[lga];
                                        $(".beat_code").html('<option value="">Please select</option>');
                                        for(var k in lga_beats){
                                            $(".beat_code").append('<option value="'+k+'">' + lga_beats[k] + '</option>');
                                        }
                                    });
                                    });
								</script>
							</select>
					
  					<br><br>
		            <a href="index.php?controller=collectors"><input class="btn btn-default bg-olive" type="button" name="back" value="Back" style="width: 80px; height: 35px; border-radius: 3px; font-size: 13px;"></a>
		            <input class="btn btn-default bg-green-gradient" type="submit" name="submit" value="Create" style="width: 80px; height: 35px; border-radius: 3px; font-size: 13px;">
                
				
                </form>
                </div>
            </div>
        </div>
</section>

<br/>
<?php 
include_once('footer.php');
?>
