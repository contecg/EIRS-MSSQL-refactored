<?php 
include_once('head.php');
include_once('navbar.php');


?>
<div class="container">
		<div class="row">
			<div><strong><h2><?php echo "Listing for Tax Payer - ".ucfirst($_GET['controller']);?></h2></strong></div>
					
  			<div class="tab-pane active" id="list">
  				<br/>
					<a href="index.php?controller=individuals"><button type="button" class="btn btn-success"> Individual Listing</button></a>
					<a href="index.php?controller=business"><button type="button" class="btn btn-success"> Business Listing</button></a>
							<a href="index.php?controller=vehicles"><button type="button" class="btn btn-success">Vehicle Listing</button></a>
						<a href="index.php?controller=company"><button type="button" class="btn btn-success">Company Listing</button></a>
						<a href="index.php?controller=scratchcard"><button type="button" class="btn btn-success">SratchCard Transactions</button></a>
				<br/>
  				<div class="table-responsive">
  					<table class="table table-hover">
    						<thead>
    							<tr>
    								<th>Payerid</th>
    								<th>Company Name</th>
    								<th>Phone</th>
    								<th>LGA</th>
    								<th>Creation Date</th>
									<th>RIN</th>
    								<th>Details</th>
    							</tr>
    						</thead>
    						<tbody>
						<?php foreach($users as $user) { ?>
    							<tr>
    								<td><?php echo $user['uuid']; ?></td>
    								<td><?php echo $user['name']; ?></td>
    								<td><?php echo $user['phone']; ?></td>
    								<td><?php echo $user['lga']; ?></td>
    								<td><?php echo 
									date('F d, Y h:mA', strtotime($user['created_at'])); ?></td>
									<td><?php echo $user['rin']; ?></td>

    								<td>
   <a href="index.php?controller=government&edit=<?php echo $user['id']; ?> "><span class="glyphicon glyphicon-edit"></span> View More</a>
   

    								</td>
    							</tr>
    						
<?php } ?>
    						</tbody>
  					</table>
				</div>
				<ul class="pagination">
  				<?php 
								$result = pg_query($conn, "SELECT count(*) FROM taxpayer where taxpayertype='government'"); 
				$reccount = (int)pg_fetch_result($result, 0, 0);
				//echo $reccount;
				if ($reccount > 20)
				{
				$numberOfPages = 30;
				for ($i=1; $i<=$numberOfPages; $i++) { ?>  
				<?php $class_active = ($page==$i)?"class='active'":$class_active="";?>
		             	<li <?php echo $class_active; ?>><a href="index.php?controller=government&page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
				<?php }; 
				}
				?>
				</ul>
  			
  </div>
  			
</div>
</section>

<?php 
include_once('footer.php');
?>
