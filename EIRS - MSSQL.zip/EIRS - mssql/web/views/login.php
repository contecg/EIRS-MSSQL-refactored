<?php 
include_once('head2.php');
//include_once('navbar2.php');

?>
<section id="page_login" class="banner">
    <div class="container">
        <h1 class="heading wow fadeInDown" style="color:#5a5345;">LOGIN DETAILS</h1>
        <hr />
        <p class="wow fadeInUp">
         <div class="row">
            <form action="" name="f1" method="post">
  

				<div class="container" style="width:40%;">
				<label for="username"><b>Enter Username</b></label>
				<input type="text" placeholder="Enter Username" name="username" id="username" required>

				<label for="password"><b>Password</b></label>
				<input type="password" placeholder="Enter Password" name="password" id="password" required>

				    <button class="btn btn-danger" type="button" id="login" style="color: white;">Login</button>



				</div>

  
			</form>
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" id="message"></div>
        </div>   
        </p>
    </div>
</section>


<?php 
include_once('footer2.php');
?>
