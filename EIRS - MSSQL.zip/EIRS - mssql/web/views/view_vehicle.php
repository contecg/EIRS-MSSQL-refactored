<?php 
include_once('head.php');
include_once('navbar.php');
?>
<script>
$(document).ready(function(){
  
});


</script>
 <!-- edit Section -->
<section id="page_edit" class="page_edit">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                 <h2>View Asset Type - Vehicle </h2>
		<hr>
		
		<?php if (isset($msg)){ ?>
		<div <?php echo $class_stat;?> role="alert"><?php echo $msg; ?><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button></div>
	<?php } ?>
		<form role="form" action="index.php?controller=individuals&edit=<?php echo $_GET['edit'];?>" method="POST">

  		
		<table class="table table-striped table-bordered table-responsive tablesorter" style="font-family: Arial; font-size: 12px; text-align:left; width: 100%;">
  <tr>
    <th style="width: 30px;">ID:</th>
    <td style="width: 30px;"><?php echo $user['id']; ?></td>
  </tr>
  <tr>
    <th>Payer ID:</th>
    <td><?php echo $user['taxpayerid']; ?></td>
  </tr>
  <tr>
    <th>Asset ID:</th>
    <td><?php echo $user['assetid']; ?></td>
  </tr>
  <tr>
    <th>Transaction ID:</th>
    <td><?php echo $user['transactionid']; ?></td>
  </tr>
  <tr>
    <th>Scratch Card:</th>
    <td><?php echo $user['scratchcard']; ?></td>
  </tr>
  <tr>
    <th>Phone:</th>
    <td><?php echo $user['mobile']; ?></td>
  </tr>
  <tr>
    <th>Agent ID:</th>
    <td><?php echo $user['agent_id']; ?></td>
  </tr>
  <tr>
    <th>Settlement ID:</th>
    <td><?php echo $user['settlementid']; ?></td>
  </tr>
  <tr>
    <th>LGA:</th>
    <td><?php echo $user['lga']; ?></td>
  </tr>
  <tr>
    <th>Payer Type:</th>
    <td><?php echo $user['taxpayertype']; ?></td>
  </tr>
  <tr>
    <th>Created At:</th>
    <td><?php echo $user['created_at']; ?></td>
  </tr>
  <tr>
    <th>Amount:</th>
    <td>&#8358;<?php echo $user['amount']; ?></td>
  </tr>
  <tr>
    <th>Asset Type:</th>
    <td><?php echo $user['assettype']; ?></td>
  </tr>
  <tr>
    <th>Sector:</th>
    <td><?php echo $user['sector']; ?></td>
  </tr>
  <tr>
    <th>Sub Sector:</th>
    <td><?php echo $user['subsector']; ?></td>
  </tr>
  <tr>
    <th>Vehicle Number:</th>
    <td><?php echo $user['vehicleno']; ?></td>
  </tr>
  
</table>
  					<a href="index.php?controller=vehicles"><button type="button" class="btn btn-success">Back</button></a>
				</form>
                </div>
            </div>
        </div>
</section>
<br/>
<?php 
include_once('footer.php');
?>
