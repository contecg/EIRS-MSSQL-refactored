<?php 
include_once('head.php');
include_once('navbar.php');
?>
<script>
$(document).ready(function(){
  
});


</script>
 <!-- edit Section -->
<section id="page_edit" class="page_edit">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                 <h2>View Tax Payer - Government </h2>
		<hr>
		
		<?php if (isset($msg)){ ?>
		<div <?php echo $class_stat;?> role="alert"><?php echo $msg; ?><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button></div>
	<?php } ?>
		<form role="form" action="index.php?controller=individuals&edit=<?php echo $_GET['edit'];?>" method="POST">

  		
		<div class="form-group">
    		<label for="username">ID</label>
	    		<?php echo $user['id'];?>
  		</div>
  		<div class="form-group">
    		<label for="password">Name </label>
			<?php echo $user['name'];?>
  		</div>

<div class="form-group">
    		<label for="password">Payer Id</label>
			<?php echo $user['uuid'];?>
  		</div>
<div class="form-group">
    		<label for="password">LGA</label>
			<?php echo $user['lga'];?>
  		</div>
  				<div class="form-group">
    		<label for="password">Address</label>
			<?php echo $user['address'];?>
  		</div>	
  			<div class="form-group">
    		<label for="password">Created At</label>
			<?php echo $user['created_at'];?>
  		</div>		
  				<div class="form-group">
    		<label for="password">Amount</label>
			<?php echo "NGN&nbsp;". $user['amount'];?>
  		</div>	
  					<a href="index.php?controller=government"><button type="button" class="btn btn-success">Back</button></a>
				</form>
                </div>
            </div>
        </div>
</section>
<br/>
<?php 
include_once('footer.php');
?>
