<?php 
include_once('head.php');
include_once('navbar.php');


?>
<!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">

          <!----- Table head ------>
	 
    <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
				<?php if($_SESSION['lga'] == "Oredo" ){ ?>	
  			<div class="tab-pane active" id="list">
  				<br/>
			
            <iframe    src="http://reports.nownowpay.ng/public/question/2f593aa6-87b9-4e0d-b178-1549979049a2"    frameborder="0"    width="100%"    height="600"    allowtransparency></iframe>
				 
				 </div>
				 <?php } ?>	
				 
				 	<?php if($_SESSION['lga'] == "Ikpoba/Okha" ){ ?>	
  			<div class="tab-pane active" id="list">
  				<br/>
			
            <iframe    src="http://reports.nownowpay.ng/public/question/065ca14b-2ae0-4bef-b876-6565fd00cb24"    frameborder="0"    width="100%"    height="600"    allowtransparency></iframe>
				 
				 </div>
				 <?php } ?>	
           <?php if($_SESSION['lga'] == "" ){ ?>
		   <div class="tab-pane active" id="list">
  				<br/>
			
            <iframe    src="https://reports.nownowpay.ng/public/question/03f3f0ce-53b6-4bdb-b983-0dcb1b9622e8?>"    frameborder="0"    width="100%"    height="600"    allowtransparency></iframe>
				  </div>
				  	 <?php } ?>
            <!-- /.box-header -->
            <div class="box-body">
  				
		
  				
				
  </div>
  				

</section>
    

<?php 
include_once('footer.php');
?>
