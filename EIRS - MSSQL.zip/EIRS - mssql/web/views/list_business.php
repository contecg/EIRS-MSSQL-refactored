<?php
include_once('head.php');
include_once('navbar.php');


?>
<div class="navbar navbar-custom" rol="navigation">

	<div class="container">
		<div><strong>
				<h2 style="color: grey;"><?php echo ucfirst($_GET['controller']); ?></h2>
			</strong></div>
	</div>

</div>

<section>
	<div>
		<form action="<?= $_SERVER['PHP_SELF']; ?>?controller=business" method="POST" class="container">

			<div class="col-sm-2 title" style="font-size: 13px;">
				<b>Payer ID:</b> <input type="text" name="payerid" placeholder="Payer ID" style="width: 130px; height: 35px; border: 1px solid #ecf0f5; margin-right: 30px; border-radius: 3px; padding: 5px; color: #33584d;">
			</div>

			<div class="col-sm-2 title" style="font-size: 13px;">
				<b>Sector:</b> <select name="sector" id="time" style="width: 130px; height: 35px; border: 1px solid #ecf0f5; border-radius: 3px; padding: 5px; color: #33584d;">
					<option value="" disabled selected>Select Sector</option>
					<?php
					$res = sqlsrv_query($conn, "SELECT distinct sector as sector FROM businesseslga ORDER BY sector ASC");
					while ($state_sel = sqlsrv_fetch_array($res)) { ?>
						<option value="<?php echo $state_sel['sector']; ?>" <?php if ($stat == $state_sel['sector']) {
																				echo "selected";
																			} ?>><?php echo ucfirst($state_sel['sector']); ?></option>
					<?php } ?>
				</select>
			</div>
			<?php if ($_SESSION['lga'] == "") { ?>
				<div class="title col-sm-2" style="font-size: 13px;">
					<b>LGA List:</b> <select name="lga" id="time" style="width: 130px; height: 35px; border: 1px solid #ecf0f5; margin-right: 30px; border-radius: 3px; padding: 5px; color: #33584d;">
						<option value="" disabled selected>Select LGA</option>
						<?php
						$res = sqlsrv_query($conn, "SELECT distinct lga as lga FROM businesseslga ORDER BY lga ASC");
						while ($state_sel = sqlsrv_fetch_array($res)) { ?>
							<option value="<?php echo $state_sel['lga']; ?>" <?php if ($stat == $state_sel['lga']) {
																					echo "selected";
																				} ?>><?php echo $state_sel['lga']; ?></option>
						<?php } ?>
					</select>
				</div>

			<?php } ?>
			<br>

			<div class="col-sm-2">
				<input class="btn btn-default bg-olive" type="submit" name="submit" value="Filter" style="width: 80px; height: 35px; border-radius: 3px; font-size: 13px;">
			</div>



	</div>
</section>

<!-- Main content -->
<section class="content">
	<div class="row">
		<div class="col-xs-12">
			<div class="box">

				<!----- Table head ------>

				<div class="row">
					<div class="col-md-12">
						<div class="box">
							<div class="box-header with-border">

								<div class="tab-pane active" id="list">
									<br />

								</div>

								<!-- /.box-header -->
								<div class="box-body">


									<?php
									$limit = 10;
									if (isset($_GET['page'])) {
										$page = $_GET["page"];
									} else {
										$page = 10;
									}
									$start_from = ($page - 1) * $limit;


									?>


									<div class="table-responsive">
										<?php

										if (empty($users)) {
											echo "<div class='alert alert-warning' style='font-size: 12px';>No Records Found.</div>";
										} else { ?>
											<table class="table table-striped table-bordered table-responsive tablesorter" style="font-family: Arial; font-size: 12px; background:#a1d3a1; text-align:center;">

												<thead style="background: #779c77;">
													<tr>
														<th style="text-align:center;">Payer Id</th>
														<th style="text-align:center;">Sector</th>
														<th style="text-align:center;">Subsector</th>
														<th style="text-align:center;">LGA</th>
														<th style="text-align:center;">Amount</th>
														<th style="text-align:center; width: 100px;">Creation Date</th>
														<th style="text-align:center;">Payer Type</th>
														<th style="text-align:center;">Captured Online</th>
														<th style="text-align:center; width: 100px;">Synced Online</th>
													</tr>
												</thead>
												<tbody>

													<?php
													$taxpayerview = $_GET['controller'];

													//print_r(sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC));
													//print_r(sqlsrv_num_rows($result));
													while ($user = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {


														?>
														<tr>
															<td><a href="index.php?controller=<?php echo $taxpayerview ?>&edit=<?php print_r($user['individual_id']); ?> "><?php echo $user['uuid']; ?></a></td>
															<td><?php print_r($user['sector']); ?></td>
															<td><?php print_r($user['subsector']); ?></td>
															<td><?php print_r($user['lga']); ?></td>
															<td>&#8358;<?php print_r($user['amount']); ?></td>
															<td><?php print_r($user['date_created']); ?></td>
															<td><?php print_r(ucfirst($user['taxpayer'])); ?></td>
															<td><?php if ($user['onlinecapture'] == 'Y') {
																	print_r("<img src=\"images/online.png\" style=\"width:25px;height:25px;\"></img>");
																} else {
																	print_r("<img src=\"images/offline.png\" style=\"width:25px;height:25px;\"></img>");
																}


																?></td>
															<td>
																<?php if ($user['onlinecapture'] == 'N') {
																	print_r($user['date_synced']);
																}
																?>
															</td>

														</tr>

													<?php
												} ?>

												</tbody>
											</table>
										</div>

										<div class="paging">
											<div class="container">
												<div class="row">
													<div class="col-md-12">
														<?php
														$page = @$_GET['page'];
														if ($page == 0 || $page == 1) {
															@$page = 0;
														} else {
															$page1 = ($page * 4) - 4;
														}
														?>

													</div>

													<ul class="pagination">

														<?php
														$links = 5;
														$sql = substr($sql, 0, -40);
														$query = sqlsrv_query($conn, $sql, array(), array("Scrollable" => SQLSRV_CURSOR_KEYSET));
														$count = sqlsrv_num_rows($query);
														$last = ceil($count / $limit);
														$start = (($page - $links) > 0) ? $page - $links : 1;
														$end = (($page + $links) < $last) ? $page + $links : $last;

														$class = ($page == 1) ? "disabled" : "";

														$previous_page = ($page > 1) ?
															'<li class="' . $class . '"><a href="index.php?controller=business&page=' . ($page - 1) . '">&laquo;</a></li>' : '<li class="disabled"><a href="">&laquo;</a></li>';
														echo $previous_page;

														if ($start > 1) {
															echo '<li><a href="index.php?controller=business&page=' . 1 . '">' . 1 . '</a></li>';
															echo '<li class="disabled"><span>...</span></li>';
														}


														for ($i = $start; $i <= $end; $i++) {
															$class = ($page == $i) ? "active" : "";
															echo '<li class="' . $class . '"><a href="index.php?controller=business&page=' . $i . '">' . $i . '</a></li>';
														}


														if ($end < $last) {
															echo '<li class="disabled"><span>...</span></li>';
															echo '<li><a href="index.php?controller=business&page=' . $last . '">' . $last . '</a></li>';
														}

														$next_page = ($page == $last) ?
															'<li class="disabled"><a href="">&raquo;</a></li>' : '<li class="' . $class . '"><a href="index.php?controller=business&page=' . ($page + 1) . '">&raquo;</a></li>';
														echo $next_page;
														?>
														<br><br><br>
														<button class="btn btn-default" type="submit" value="Print" formaction="<?= $_SERVER['PHP_SELF']; ?>?controller=collectors" style="color: red; font-size: 12px; height: 35px; width: 37px;" onclick="window.print()"><span class="glyphicon glyphicon-print"></span></button>
														<button class="btn btn-default" type="submit" id="filter" name="filter" value="Download" formaction="models/business-excel.php" style="color: red; font-size: 12px; height: 35px; width: 37px;"><span class="glyphicon glyphicon-download-alt"></span></button>
														</form>

													</ul>

												</div>
											<?php

										} ?>
										</div>


</section>







<?php
include_once('footer.php');
?>