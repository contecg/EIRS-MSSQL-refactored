<?php 
include_once('head.php');
include_once('navbar.php');
?>
<script>
$(document).ready(function(){
  
});


</script>
 <!-- edit Section -->
<section id="page_edit" class="page_edit">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                 <h2>View Asset Type - Business </h2>
		<hr>
		
		<?php if (isset($msg)){ ?>
		<div <?php echo $class_stat;?> role="alert"><?php echo $msg; ?><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button></div>
	<?php } ?>
		<form role="form" action="index.php?controller=business&edit=<?php echo $_GET['edit'];?>" method="POST">

  		
		<div class="form-group">
    		<label for="username">ID</label>&nbsp : &nbsp
	    	<?php echo $user['id']?>	
  		</div>
  		<div class="form-group">
    		<label for="password">Name </label>&nbsp : &nbsp
			<?php echo $user['name']?>
  		</div>

<div class="form-group">
    		<label for="password">Payer Id</label>&nbsp : &nbsp
			<?php echo $user['payer_id']?>
  		</div>
<div class="form-group">
    		<label for="password">LGA</label>&nbsp : &nbsp
			<?php echo $user['lga']?>
  		</div>
  				<div class="form-group">
    		<label for="password">Amount</label>&nbsp : &nbsp
			<?php echo $user['amount']?>
  		</div>	
  			<div class="form-group">
    		<label for="password">Created At</label>&nbsp : &nbsp
			<?php echo $user['created_at']?>
  		</div>		
  				<div class="form-group">
    		<label for="password">Sector</label>&nbsp : &nbsp
			<?php echo $user['sector']?>
  		</div>	
				<div class="form-group">
    		<label for="password">Sub-Sector</label>&nbsp : &nbsp
			<?php echo $user['subsector']?>
  		</div>	
  					<a href="index.php?controller=business"><button type="button" class="btn btn-success">Back</button></a>
				</form>
                </div>
            </div>
        </div>
</section>
<br/>
<?php 
include_once('footer.php');
?>
