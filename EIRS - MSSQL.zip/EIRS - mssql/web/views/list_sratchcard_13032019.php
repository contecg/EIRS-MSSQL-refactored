<?php 
include_once('head.php');
include_once('navbar.php');


?>
<!-- Main content -->
<div class="navbar navbar-custom" rol="navigation">
		
		<div class="container">
			<div><strong><h2 style="color: grey;"><?php echo ucfirst($_GET['controller']); ?></h2></strong></div>		
			</div>
		
</div>

	<section>
    
      <div>      
          
          <form action="<?= $_SERVER['PHP_SELF']; ?>?controller=scratchcard" method="POST" class="container">
          	<div class="col-sm-2 title" style="font-size: 13px;">
			  
				<b>Date Range:</b> <input type="text" name="daterange" value="<?php if (!isset($_POST['daterange'])) { echo ""; } ?>"  style="width: 150px; height: 35px; border: 1px solid #ecf0f5; margin-right: 30px; border-radius: 3px; padding: 5px; color: #33584d;"/>
				
				<script>
					$(function() {
					$('input[name="daterange"]').daterangepicker({
						opens: 'right'
					}, function(start, end, label) {
					});
					});
				</script>
        	</div>

			<div class="col-sm-2 title" style="font-size: 13px;">
				<b>Tranasaction ID:</b>  <input type="text" name="transactionid" placeholder="Transaction ID" style="width: 130px; height: 35px; border: 1px solid #ecf0f5; margin-right: 30px; border-radius: 3px; padding: 5px; color: #33584d;">
			</div>

			<div class="col-sm-2 title" style="font-size: 13px;">
				<b>Sector:</b>  <select name="sector" id="time" style="width: 130px; height: 35px; border: 1px solid #ecf0f5; margin-right: 30px; border-radius: 3px; padding: 5px; color: #33584d;">
              <option value="">Please Select</option>              				
				<?php 
				$res = pg_query($conn, "SELECT distinct(initcap(sector)) as sector FROM transactions ORDER BY sector ASC");
				while ($state_sel = pg_fetch_assoc($res)) { ?>
					<option value="<?php echo strtoupper($state_sel['sector']); ?>" <?php if ($stat == $state_sel['sector']) { echo "selected"; } ?>><?php echo ucfirst($state_sel['sector']); ?></option>
				<?php }?>
            </select>
        	</div>

		<div class="col-sm-2 title" style="font-size: 13px;">
            <b>Denomination:</b>  <select name="denomination" id="time" style="width: 130px; height: 35px; border: 1px solid #ecf0f5; margin-right: 30px; border-radius: 3px; padding: 5px; color: #33584d;">
				<option value="">Please Select</option>
				<?php 
				$res = pg_query($conn, "SELECT distinct(amount) as amount FROM transactions ORDER BY amount ASC");
				while ($state_sel = pg_fetch_assoc($res)) { ?>
					<option value="<?php echo $state_sel['amount']; ?>" <?php if ($stat == $state_sel['amount']) { echo "selected"; } ?>>&#8358;<?php echo $state_sel['amount']; ?></option>
				<?php }?>		  
            </select>
        </div>

            <br>

		<div class="col-sm-2">
            <input class="btn btn-default bg-olive" type="submit" name="submit" value="Filter" style="width: 80px; height: 35px; border-radius: 3px; font-size: 13px;">
		</div>

            
          
        </div>
    </section>

    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">

          <!----- Table head ------>

    <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
					
  			<div class="tab-pane active" id="list">
  				
  				<!-- /.box-header -->
            <div class="box-body">


			<?php
		$limit = 20;
		if (isset($_GET['page'])) {
			$page = $_GET["page"];
		} else {
			$page = 10;
		}
		$start_from = ($page - 1) * $limit;


		?>
  				
				
  				<div class="table-responsive">
				  <?php
					if (empty($users)) {
						echo "<div class='alert alert-warning' style='font-size: 12px';>No Records Found.</div>";
					} else { ?>
  					<table class="table table-striped table-bordered table-hover table-responsive tablesorter" style="font-family: Arial; font-size: 12px; background:#a1d3a1; text-align:center;">
    						<thead style="background: #779c77;">
    							<tr>
    								<th style="text-align:center;">Payerid</th>
									
    								<th style="text-align:center;">AssetId</th>
    								<th style="text-align:center;">TransactionId</th>
    								<th style="text-align:center;">Transaction Date</th>
    								<th style="text-align:center;">Amount</th>
									<th style="text-align:center;">ScratchCard</th>
									<th style="text-align:center;">Settlement</th>
									<th style="text-align:center;">Sector</th>
    							</tr>
    						</thead>
    						<tbody>
						<?php foreach($users as $user) {
						switch ($user['taxpayertype']) {
							case "individual":
								$taxpayerview = "individual";
								break;
							case "company":
								$taxpayerview = "company";
								break;
							case "government":
								$taxpayerview = "government";
								break;
						}
							?>
    							<tr>
    								<td><a href="index.php?controller=scratchcard&edit=<?php echo $user['id']; ?> "><?php echo $user['taxpayerid']; ?></a></td>
    								<td><?php echo $user['assetid']; ?></td>
    								<td><?php echo $user['transactionid']; ?></td>
    								<td><?php echo $user['created_at']; ?></td>
									<td>&#8358;<?php echo $user['amount']; ?></td>
									<td><?php echo $user['scratchcard']; ?></td>
									<td><?php echo "Scratch Card" ?></td>
									<td><?php echo $user['sector']; ?></td>
								</tr>
															
								<?php } ?>
								<tr>
								<?php
							if (empty($users)) {
								echo "<div class='alert alert-warning' style='font-size: 12px';>No Records Found.</div>";
							} ?></tr>
    						</tbody>
  					</table>
				</div>
	
							<div class="paging">
								<div class="container">
									<div class="row">
										<div class="col-md-12">
											<?php
										$page = @$_GET['page'];
										if ($page == 0 || $page == 1) {
											@$page = 0;
										} else {
											$page1 = ($page * 4) - 4;
										}
										?>
                          
                      </div>

				<ul class="pagination">
  				
				  <?php 
					$links = 5;
					$sql = substr($sql, 0, -22);
					$query = pg_query($sql);
					$count = pg_num_rows($query);
					$last = ceil($count / $limit);
					$start = (($page - $links) > 0) ? $page - $links : 1;
					$end = (($page + $links) < $last) ? $page + $links : $last;

					$class = ($page == 1) ? "disabled" : "";

					$previous_page = ($page > 1) ?
						'<li class="' . $class . '"><a href="index.php?controller=scratchcard&page=' . ($page - 1) . '">&laquo;</a></li>' :
						'<li class="disabled"><a href="">&laquo;</a></li>';
					echo $previous_page;

					if ($start > 1) {
						echo '<li><a href="index.php?controller=scratchcard&page=' . 1 . '">' . 1 . '</a></li>';
						echo '<li class="disabled"><span>...</span></li>';
					}


					for ($i = $start; $i <= $end; $i++) {
						$class = ($page == $i) ? "active" : "";
						echo '<li class="' . $class . '"><a href="index.php?controller=scratchcard&page=' . $i . '">' . $i . '</a></li>';
					}


					if ($end < $last) {
						echo '<li class="disabled"><span>...</span></li>';
						echo '<li><a href="index.php?controller=scratchcard&page=' . $last . '">' . $last . '</a></li>';
					}

					$next_page = ($page == $last) ?
						'<li class="disabled"><a href="">&raquo;</a></li>' :
						'<li class="' . $class . '"><a href="index.php?controller=scratchcard&page=' . ($page + 1) . '">&raquo;</a></li>';
					echo $next_page;
					?>

					<br><br><br>
            		<button class="btn btn-default" type="submit" value="Print" formaction="<?= $_SERVER['PHP_SELF']; ?>?controller=collectors" style="color: red; font-size: 12px; height: 35px; width: 37px;" onclick="window.print()"><span class="glyphicon glyphicon-print"></span></button>
					<button class="btn btn-default" type="submit" id="filter" name="filter" value="Download" formaction="models/scratchcard-excel.php" style="color: red; font-size: 12px; height: 35px; width: 37px;"><span class="glyphicon glyphicon-download-alt"></span></button>
					</form>
				</ul>
  			
  </div>
  	<?php

	} ?>
</div>
  			
</section>
    

<?php 
include_once('footer.php');
?>
