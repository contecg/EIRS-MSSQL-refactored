<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EIRS</title>
    
    <style>


input[type=text], input[type=password] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

button {
    background-color: #c30001a6;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 47%;
}

button:hover {
    opacity: 0.8;
}

.cancelbtn {
    width: auto;
    padding: 10px 18px;
    background-color: #f44336;
}

.imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
}

img.avatar {
    width: 40%;
    border-radius: 50%;
}

.container {
    padding: 16px;
}

span.psw {
    float: right;
    padding-top: 16px;
}
</style>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/simple-line-icons.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap-select.min.css">
<link rel="stylesheet" type="text/css" href="css/components.min.css">
<link rel="stylesheet" type="text/css" href="css/layout.min.css">
<link rel="stylesheet" type="text/css" href="css/plugins.min.css">
<link rel="stylesheet" type="text/css" href="css/theme.min.css">
<link rel="stylesheet" type="text/css" href="css/custom.css">
<link rel="dns-prefetch" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">
<link rel="shortcut icon" href="images/favicon.jpg">
<script type="text/javascript" src="js/jquery.1.8.1.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/login.js"></script>
     
</head>
<body>
    <div id="domMessage" style="display:none;">
        <h4></h4>
    </div>
    <header>
        <div class="top-bar">
            <div class="container">
                <div class="navbar-header">
                    <a href="index.html" class="navbar-brand">
                        <img src="images/EIRS-logo.png" />
                      <!--  <img src="images/Logo.png" /> -->
                        <h1 class="heading wow fadeInDown" style="margin-left: 240px;margin-top: 4px;color:#c00001;">Edo State Internal Revenue Service (EIRS) </h1> 
                    </a>
                </div>
                
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navMainMenu" aria-expanded="false">
                    <i class="fa fa-bars"></i>
                </button>
            </div>
        </div>
        <div class="navbar navbar-default">
            <div class="container">
                <div class="navbar-collapse collapse" id="navMainMenu" aria-expanded="false">
                    
                    
                </div>
            </div>
        </div>
    </header>