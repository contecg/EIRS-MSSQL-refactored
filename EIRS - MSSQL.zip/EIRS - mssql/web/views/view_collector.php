<?php 
include_once('head.php');
include_once('navbar.php');
?>
<script>
$(document).ready(function(){
  
});


</script>
 <!-- edit Section -->
<section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">

          <!----- Table head ------>

    <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
					
  			<div class="tab-pane active" id="list">
  				<br/>

				  </div>
            
            <!-- /.box-header -->
            <div class="box-body">
                 <h2 style="color: gray;">Collector Details</h2>
		<hr>
		
		<?php if (isset($msg)) { ?>
		<div <?php echo $class_stat; ?> role="alert"><?php echo $msg; ?><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button></div>
	<?php 
} ?>
		<form role="form" action="index.php?controller=collector&edit=<?php echo $_GET['edit']; ?>" method="POST">

  		
		<table class="table table-striped table-bordered table-responsive tablesorter" style="font-family: Arial; font-size: 12px; text-align:left; width: 100%;">
  <tr>
    <th style="width: 30px;">ID:</th>
    <td style="width: 30px;"><?php echo $user['id']; ?></td>
  </tr>
  <tr>
    <th>Phone:</th>
    <td><?php if (empty($user['phone'])) {
		echo '<p style="color: silver">' . 'Empty' . '</p>';
	} else { echo $user['phone']; } ?></td>
  </tr>
  <tr>
    <th>First Name:</th>
    <td><?php if (empty($user['first_name'])) {
		echo '<p style="color: silver">' . 'Empty' . '</p>';
	} else { echo $user['first_name']; } ?></td>
  </tr>
  <tr>
    <th>Last Name:</th>
    <td><?php if (empty($user['last_name'])) {
		echo '<p style="color: silver">' . 'Empty' . '</p>';
	} else { echo $user['last_name']; } ?></td>
  </tr>
  <tr>
    <th>LGA:</th>
    <td><?php if (empty($user['lga'])) {
		echo '<p style="color: silver">' . 'Empty' . '</p>';
	} else { echo $user['lga']; } ?></td>
  </tr>
  <tr>
    <th>Revenue Beat:</th>
    <td><?php if (empty($user['beat_code'])) {
		echo '<p style="color: silver">' . 'Empty' . '</p>';
	} else { echo $user['beat_code']; } ?></td>
  </tr>
  <tr>
    <th>Address:</th>
    <td><?php if (empty($user['address'])) {
		echo '<p style="color: silver">' . 'Empty' . '</p>';
	} else { echo $user['address']; } ?></td>
  </tr>
  <tr>
    <th>Birth Place:</th>
    <td><?php if (empty($user['birthplace'])) {
		echo '<p style="color: silver">' . 'Empty' . '</p>';
	} else { echo $user['birthplace']; } ?></td>
  </tr>
  <tr>
    <th>State</th>
    <td><?php if (empty($user['state'])) {
		echo '<p style="color: silver">' . 'Empty' . '</p>';
	} else { echo $user['state']; } ?></td>
  </tr>
  <tr>
    <th>Date of Birth:</th>
    <td><?php if (empty($user['dob'])) {
		echo '<p style="color: silver">' . 'Empty' . '</p>';
	} else { echo $user['dob']; } ?></td>
  </tr>
</table>	


<table class="table table-striped table-bordered table-hover table-responsive tablesorter" style="font-family: Arial; font-size: 12px; background:#a1d3a1; text-align:center;">
							<thead style="background: #779c77;">
    							<tr>
									<th style="text-align:center;">Transaction ID</th>
									<th style="text-align:center;">Created At</th>
									<th style="text-align:center;">LGA</th>
									<th style="text-align:center;">Sub-Sector</th>
									<th style="text-align:center;">Sector</th>
									<th style="text-align:center;">Amount</th>
    							</tr>
    						</thead>
    						<tbody>
							
							
    						<?php while ($usr = sqlsrv_fetch_array($res)) {?>
    							<tr>	
										<td><?php if (empty($usr['transactionid'])) {
										echo '<p style="color: silver">' . 'Empty' . '</p>';
									} else { echo $usr['transactionid']; } ?></td>
									
										<td><?php if (empty($usr['created_at'])) {
										echo '<p style="color: silver">' . 'Empty' . '</p>';
									} else { echo date("m/d/Y", strtotime($usr['created_at'])); } ?></td>
										<td><?php if (empty($usr['lga'])) {
										echo '<p style="color: silver">' . 'Empty' . '</p>';
									} else { echo $usr['lga']; } ?></td>
										<td><?php if (empty($usr['subsector'])) {
										echo '<p style="color: silver">' . 'Empty' . '</p>';
									} else { echo $usr['subsector']; } ?></td>
										<td><?php if (empty($usr['sector'])) {
										echo '<p style="color: silver">' . 'Empty' . '</p>';
									} else { echo $usr['sector']; } ?></td>
										<td>&#8358;<?php if (empty($usr['amount'])) {
										echo '<p style="color: silver">' . 'Empty' . '</p>';
									} else { echo $usr['amount']; } ?></td>
    							
    						
								
								
							</tr>
							<?php } ?>
    						</tbody>
  					</table>



				
	<a href="index.php?controller=collectors"><button type="button" class="btn bg-green-gradient">Back</button></a>

</form>
                </div>
            </div>
        </div>
</section>
<br/>
<?php 
include_once('footer.php');
?>
