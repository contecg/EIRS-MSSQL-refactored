<?php 
include_once('head.php');
include_once('navbar.php');
?>
<script>
$(document).ready(function(){
  
});


</script>
 <!-- edit Section -->
<section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">

          <!----- Table head ------>

    <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
					
  			<div class="tab-pane active" id="list">
  				<br/>

				  </div>
            
            <!-- /.box-header -->
            <div class="box-body">
                 <h2 style="color: gray;">Tax Payer Details</h2>
		<hr>
		
		<?php if (isset($msg)) { ?>
		<div <?php echo $class_stat; ?> role="alert"><?php echo $msg; ?><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button></div>
	<?php 
} ?>
		<form role="form" action="index.php?controller=individuals&edit=<?php echo $_GET['edit']; ?>" method="POST">

  		

<table class="table table-striped table-bordered table-responsive tablesorter" style="font-family: Arial; font-size: 12px; text-align:left; width: 100%;">
  <tr>
    <th style="width: 30px;">ID:</th>
    <td style="width: 30px;"><?php echo $user['id']; ?></td>
  </tr>
  <tr>
    <th>Payer ID:</th>
    <td><?php echo $user['uuid']; ?></td>
  </tr>
  <tr>
    <th>First Name:</th>
    <td><?php echo $user['first_name']; ?></td>
  </tr>
  <tr>
    <th>last Name:</th>
    <td><?php echo $user['last_name']; ?></td>
  </tr>
  <tr>
    <th>Mother's Name:</th>
    <td><?php echo $user['mothers_name']; ?></td>
  </tr>
  <tr>
    <th>Phone:</th>
    <td><?php echo $user['phone']; ?></td>
  </tr>
  <tr>
    <th>Gender:</th>
    <td><?php echo $user['gender']; ?></td>
  </tr>
  <tr>
    <th>Date of Birth:</th>
    <td><?php echo $user['dob']; ?></td>
  </tr>
  <tr>
    <th>LGA:</th>
    <td><?php echo $user['lga']; ?></td>
  </tr>
  <tr>
    <th>Address:</th>
    <td><?php echo $user['address']; ?></td>
  </tr>
  <tr>
    <th>Created At:</th>
    <td><?php echo $user['created_at']; ?></td>
  </tr>
  <tr>
    <th>Amount:</th>
    <td><?php echo $user['amount']; ?></td>
  </tr>
  <tr>
    <th>State:</th>
    <td><?php echo $user['state_of_origin']; ?></td>
  </tr>
  <tr>
    <th>Nationality:</th>
    <td><?php echo $user['nationality']; ?></td>
  </tr>
  <tr>
    <th>Marital Status:</th>
    <td><?php echo $user['marital_status']; ?></td>
  </tr>
  
    <th>RIN:</th>
    <td><?php if (empty($user['rin'])) {
          echo "<div style='color: silver'>Empty</div>";
        } else {
          echo $user['rin'];
        }
        ?></td>
  </tr>
  <tr>
    <th>Tax Payer Type:</th>
    <td><?php echo $user['taxpayertype']; ?></td>
  </tr>
  
</table>
  					<a href="index.php?controller=<?php echo $taxpayerview; ?>"><button type="button" class="btn bg-green-gradient">Back</button></a>
				</form>
                </div>
            </div>
        </div>
</section>
<br/>
<?php 
include_once('footer.php');
?>
