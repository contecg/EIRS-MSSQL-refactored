<?php
require_once 'Classes/PHPExcel.php';
require_once 'Classes/PHPExcel/IOFactory.php';
require_once '../models/collector.php';

//database connection
$conn = pg_connect("host=esir-connect.ckrkdy50shek.eu-west-1.rds.amazonaws.com dbname=card_vault user=app_street password=appstreet");


//create PHPExcel object
$excel = new PHPExcel();

$excel->setActiveSheetIndex(0);
$excel->getActiveSheet()->setTitle("Collectors");

//populate the data
if (empty($_POST['name']) && empty($_POST['phone']) && empty($_POST['state']) && empty($_POST['lga'])) {
        $cond = "";
        $sql = "SELECT first_name||' '||last_name as name, phone, address, birthplace, state, to_char(created_at, 'D-Mon-YYYY') as created_at, to_char(dob, 'D-Mon-YYYY') as dob, lga, amount  FROM agents $cond ORDER BY created_at DESC";
    } elseif (isset($_POST['lga']) && empty($_POST['phone']) && empty($_POST['state']) && empty($_POST['name'])) {
        $lga = $_POST['lga'];
        $cond = " WHERE lga = '$lga' ";
        $sql = "SELECT first_name||' '||last_name as name, phone, address, birthplace, state, to_char(created_at, 'D-Mon-YYYY') as created_at, to_char(dob, 'D-Mon-YYYY') as dob, lga, amount  FROM agents $cond ORDER BY created_at DESC";
    } elseif (isset($_POST['state']) && empty($_POST['phone']) && empty($_POST['name']) && empty($_POST['lga'])) {
        $state = $_POST['state'];
        $cond = " WHERE state = '$state' ";
        $sql = "SELECT first_name||' '||last_name as name, phone, address, birthplace, state, to_char(created_at, 'D-Mon-YYYY') as created_at, to_char(dob, 'D-Mon-YYYY') as dob, lga, amount  FROM agents $cond ORDER BY created_at DESC";
    } elseif (isset($_POST['name']) && empty($_POST['phone']) && empty($_POST['state']) && empty($_POST['lga'])) {
        //$name = $_POST['name'];
        $name = pg_escape_string($conn, $_POST['name']);
        $cond = " WHERE first_name LIKE '%$name%' OR last_name LIKE '%$name%' ";
        $sql = "SELECT first_name||' '||last_name as name, phone, address, birthplace, state, to_char(created_at, 'D-Mon-YYYY') as created_at, to_char(dob, 'D-Mon-YYYY') as dob, lga, amount  FROM agents $cond ORDER BY created_at DESC";
    } elseif (isset($_POST['phone']) && empty($_POST['name']) && empty($_POST['state']) && empty($_POST['lga'])) {
        $phone = $_POST['phone'];
        $cond = " WHERE phone LIKE '%$phone%' ";
        $sql = "SELECT first_name||' '||last_name as name, phone, address, birthplace, state, to_char(created_at, 'D-Mon-YYYY') as created_at, to_char(dob, 'D-Mon-YYYY') as dob, lga, amount  FROM agents $cond ORDER BY created_at DESC";
    } elseif (isset($_POST['name']) && isset($_POST['phone']) && isset($_POST['state']) && isset($_POST['lga'])) {
        $name = $_POST['name'];
        $phone = $_POST['phone'];
        $state = $_POST['state'];
        $lga = $_POST['lga'];
        $cond = " WHERE first_name = '%$name%' AND phone LIKE '%$phone%' AND state = '$state' AND lga = '$lga' ";
        $sql = "SELECT first_name||' '||last_name as name, phone, address, birthplace, state, to_char(created_at, 'D-Mon-YYYY') as created_at, to_char(dob, 'D-Mon-YYYY') as dob, lga, amount  FROM agents $cond ORDER BY created_at DESC";
    } elseif (isset($_POST['name']) || isset($_POST['phone']) || isset($_POST['state']) || isset($_POST['lga'])) {
        $name = $_POST['name'];
        $phone = $_POST['phone'];
        $state = $_POST['state'];
        $lga = $_POST['lga'];
        $cond = " WHERE first_name = '%$name%' OR phone LIKE '%$phone%' OR state = '$state' OR lga = '$lga' ";
        $sql = "SELECT first_name||' '||last_name as name, phone, address, birthplace, state, to_char(created_at, 'D-Mon-YYYY') as created_at, to_char(dob, 'D-Mon-YYYY') as dob, lga, amount  FROM agents $cond ORDER BY created_at DESC";
    } 
    //echo $sql;
$query = pg_query($sql);
$row = 2;
while ($data = pg_fetch_object($query)) {
    $excel->getActiveSheet()
        ->setCellValue('A'.$row, $data->name)
        ->setCellValue('B'.$row, $data->phone)
        ->setCellValue('C'.$row, $data->address)
        ->setCellValue('D'.$row, $data->birthplace)
        ->setCellValue('E'.$row, $data->state)
        ->setCellValue('F'.$row, $data->created_at)
        ->setCellValue('G'.$row, $data->dob)
        ->setCellValue('H'.$row, $data->lga);
    //increament for row
    $row++;
}

//set column width
$excel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('E')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('F')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('G')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('H')->setWidth(20);


    
//make table headers
$excel->getActiveSheet()
    ->setCellValue('A1', 'Name')
    ->setCellValue('B1', 'Phone')
    ->setCellValue('C1', 'Address')
    ->setCellValue('D1', 'Place of Birth')
    ->setCellValue('E1', 'State')
    ->setCellValue('F1', 'Date Created')
    ->setCellValue('G1', 'Date of Birth')
    ->setCellValue('H1', 'LGA');

//merging title cells
$excel->getActiveSheet()->getStyle('A1:H1');

//aligning
$lastrow = $excel->getActiveSheet()->getHighestRow();
$excel->getActiveSheet()->getStyle('A1:H'.$lastrow)->getAlignment()->setHorizontal('center');


//styling
$excel->getActiveSheet()->getStyle('A1:H'.$lastrow)->applyFromArray(
    array(
        'font' => array(
            'size' => 11,
            'name' => 'Arial',
        )
    )
);

$excel->getActiveSheet()->getStyle('A1:H1')->applyFromArray(
    array(
        'font' => array(
            'bold' => 'true'
        )
    )
);

//--------------------------------------------------

$file = "ESIRconnect".date('Y-m-d H-i-s').".xls";
$dir = 'myDir';


 if ( !file_exists($dir) ) {
     mkdir ($dir, 0744);
 }


    header('Content-Type: application/vnd.vnd.ms-excel');
    header('Content-Transfer-Encoding: base64');
    header('Content-disposition: attachment; filename=collectors.xls');
//write the result to a file
$write = PHPExcel_IOFactory::createWriter($excel, 'Excel5');
$write->save('php://output');
