<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<title>EIRS Connect LGA Dashboard</title>

  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <!-- Date Picker -->
  <link rel="stylesheet" href="bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="bower_components/bootstrap-daterangepicker/daterangepicker.css">
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <!-- Google Font -->
  <link rel="dns-prefetch" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,400i,500,500i,600,600i,700,700i,800,800i" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Poppins:400,400i,500,500i,600,600i,700,700i,800,800i" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Roboto:400,400i,500,500i" rel="stylesheet">
  <link rel="shortcut icon" href="images/favicon.jpg">
  <script src="bower_components/jquery/dist/jquery.min.js"></script>
  <script type="text/javascript" src="js/login.js"></script>
</head>

<body class="skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
<!-- Logo -->
    <a href="index.php?controller=dashboard" class="logo" style="background: white; position: fixed;">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><img src="images/eirs-logo-small.jpg" alt="eirs-logo"></span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><img src="images/eirs-logo.png" alt="eirs-logo" style="width:200px; height:60px;"></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top" style="background: #034b33;">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button" style="background: #012e1f;">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Messages: style can be found in dropdown.less-->
          
          <!-- User Account: style can be found in dropdown.less -->
          <?php if (isset($_SESSION['username'])) { ?>
				
				<ul class="nav navbar-nav">
					
					<li class="dropdown">
						<a href="#" class="data-toggle">
							<i class="glyphicon glyphicon-user"></i>
							
								Welcome: <?= $_SESSION['username']; ?>
							
							</a>
					</li>
					<li><a href="index.php?controller=logout"><b class="glyphicon glyphicon-log-out"></b>Logout </a></li>
				</ul>
				<?php 
		} ?>

          <!-- Control Sidebar Toggle Button -->
          <!--
          <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li>
          -->

        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar" style="position: fixed;">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
     
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree" >
        <li class="header">MAIN NAVIGATION</li>
        <li>
        <a href="index.php?controller=dashboard">
            <i class="fa fa-dashboard"></i>
            <span>Dashboard</span>
          </a>
        </li>
		<li>
		<a href="index.php?controller=business">
            <i class="fa fa-briefcase"></i>
            <span>Business Listing</span>
          </a>
        </li>
		<li>
		<a href="index.php?controller=collectors">
            <i class="fa fa-user"></i>
            <span>LGA Collectors</span>
          </a>
        </li>
		<li>
		<a href="index.php?controller=scratchcard">
            <i class="fa fa-credit-card"></i>
            <span>Scratch Card Transactions</span>
          </a>
        </li>
		<li>
		<a href="index.php?controller=collbreakdown">
            <i class="fa fa-credit-card"></i>
            <span>Collections Breakdown</span>
          </a>
        </li>
		<li>
		<a href="index.php?controller=taxpayers">
            <i class="fa fa-users"></i>
            <span>Taxpayers Listing</span>
          </a>
        </li>
		<li>
		<a href="index.php?controller=vehicles">
            <i class="fa fa-car"></i>
            <span>Vehicle Listing</span>
          </a>
        </li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>