<?php
include 'conn.php';
global $uniquelga;
	$message_ok=false;
	$message_error='The system is not available';
	if(isset($_POST['username']) || isset($_POST['password'])):
		if($_POST['username']!=""):
			if($_POST['password']!=""):
				$username=$_POST['username'];
				$password=md5($_POST['password']);
				$res=sqlsrv_query($conn, "select * from user_tbl where username='$username' and CONVERT(NVARCHAR(MAX), password) ='$password'");
				if(sqlsrv_has_rows($res)):
					$message_ok=true;
					$user_list=sqlsrv_fetch_array($res);
					$_SESSION['id']=$user_list[0];
					$_SESSION['username']=$user_list[1];
					$_SESSION['lga']=$user_list[5];
					$uniquelga = $_SESSION['lga'];
					$message_error='logged now...';
				else:
					$message_error='Login failed,please check your login account again';
				endif;
			else:
				$message_error='Wrong password.';
			endif;
		else:
			$message_error='username not existed.';
		endif;
	else:
		$message_error='All fields are required.';
	endif;
	$json=array('data' => $message_ok, 'message' =>$message_error);
	echo json_encode($json);
