<?php
locked();
include_once('conn.php');
include_once('models/add_collector.php');

//show users list
if (!isset($_GET['edit']) && !isset($_GET['del']) && !isset($_GET['add'])) {
    $countPerPage = 3;
    $totalResultCount = count_users($conn);

	// The ceil function will round floats up.
    $numberOfPages = ceil($totalResultCount / $countPerPage);

	// Check if we have a page number in the _GET parameters
    if (!empty($_GET) && isset($_GET['page'])) {
        $page = (int)$_GET['page'];
    } else {
        $page = 1;
    }

	// Check that the page is within our bounds
    if ($page < 0) {
        $page = 1;
    } elseif ($page > $numberOfPages) {
        $page = $numberOfPages;
    }

    $users = get_users_paging($conn, $page, $countPerPage);
    include('views/list_addcollector.php');
} 
//deleted action
elseif (isset($_GET['del'])) {
    $where = array("id" => $_GET['del']);
    del_user($conn, $where);
    header("Location: index.php?controller=users");
    exit();
}

//edit action
elseif (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
	//if form is submitted.
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $where_condition = array("id" => $_GET['edit']);
        $msg = "";
        $class_stat = 'class="alert alert-info"';
        if (trim($_POST['password']) != trim($_POST['confirm_password'])) {
            $msg = "Your password does not match your confirmed password.";
            $class_stat = 'class="alert alert-warning"';
        } else {
            $_POST['password'] = md5($_POST['password']);
            unset($_POST['confirm_password']);
            $data = $_POST;
            $is_updated = update_user($conn, $data, $where_condition);
            if ($is_updated) {
                $msg = "Data is updated.";
                $class_stat = 'class="alert alert-info"';
            } else {
                $msg = "Error input.";
                $class_stat = 'class="alert alert-warning"';
            }
        }

    }
	// get user record informaation.
    $user = get_user($conn, $_GET['edit']);
    include('views/edit_user.php');

} elseif (isset($_GET['add'])) {
	//if form is submitted.
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {

        //$msg = "";
        //$class_stat = 'class="alert alert-info"';
        if (isset($_POST['phone'])) {
            //$msg = "Your password does not match your confirmed password.";
            //$class_stat = 'class="alert alert-warning"';
            $phone = $_POST['phone'];
            $firstname = $_POST['firstname'];
            $lastname = $_POST['lastname'];
            $address = $_POST['address'];
            $birthplace = $_POST['birthplace'];
            $state = $_POST['state'];
            $lga = $_POST['lga'];
            $revenuebeat = $_POST['revenuebeat'];
            echo $phone.' ' . $firstname . ' ' . $lastname . ' ' . $address . ' ' . $birthplace . ' ' . $state . ' ' . $lga . ' ' . $revenuebeat;
            $msg = "Collector registered successfully!";
            $class_stat = 'class="alert alert-success"';
        } else {
            $msg = pg_last_error();
            $class_stat = 'class="alert alert-danger"';
        }
        /*$users = "INSERT INTO agents (phone, first_name, last_name, address, birthplace, state, lga, beat_code, created_at, updated_at, status) 
          VALUES ('$phone', '$firstname', '$lastname', '$address', '$birthplace', '$state', '$lga', '$revenuebeat', now(), now(), 'A')";
          //$users = explode(',', $users) . "<br/><br/>";
        print_r($users)."<br/><br/>";

        if (pg_query($conn, $users)) {
            echo "New record created successfully";
        } */

        //if(is_array($users)) {
        print_r($user) . "<br/><br/>";
        

        //}
          
	        //redirect to user list
		//header("Location: index.php?controller=collectors"); 
		//exit();

    }
    include('views/add_collector.php');


}

?>
