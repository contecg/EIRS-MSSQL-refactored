<?php
require_once 'Classes/PHPExcel.php';
require_once 'Classes/PHPExcel/IOFactory.php';

//database connection
$conn = mysqli_connect("localhost", "root", "", "report");
if(!$conn){
    echo mysqli_error($conn);
    exit;
}

//create PHPExcel object
$excel = new PHPExcel();

//selecting active sheet
$excel->setActiveSheetIndex(0);
$excel->getActiveSheet()->setTitle("Collectors");

//populate the data
$query = mysqli_query($conn, "select * from demo");
$row = 2;
while ($data = mysqli_fetch_object($query)) {
    $excel->getActiveSheet()
        ->setCellValue('A'.$row, $data->id)
        ->setCellValue('B'.$row, $data->country)
        ->setCellValue('C'.$row, $data->state)
        ->setCellValue('D'.$row, $data->city)
        ->setCellValue('E'.$row, $data->pin);
    //increament for row
    $row++;
}


//set column width
$excel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
$excel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('E')->setWidth(20);
    
//make table headers
$excel->getActiveSheet()
    ->setCellValue('A1', 'ID')
    ->setCellValue('B1', 'Country')
    ->setCellValue('C1', 'State')
    ->setCellValue('D1', 'City')
    ->setCellValue('E1', 'Pin');

//merging title cells
$excel->getActiveSheet()->getStyle('A1:E1');

//aligning
$excel->getActiveSheet()->getStyle('A1:E1')->getAlignment()->setHorizontal('center');


//styling
$excel->getActiveSheet()->getStyle('A1:E1')->applyFromArray(
    array(
        'font' => array(
            'size' => 13,
        )
    )
);

$excel->getActiveSheet()->getStyle('A1:E1')->applyFromArray(
    array(
        'font' => array(
            'bold' => 'true'
        )
    )
);

//Header background color
$excel->getActiveSheet()->getStyle('A1:E1')->getFill()
->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
->getStartColor()->setRGB('f3c385');


//Data from second table


$excel->createSheet();

$excel->setActiveSheetIndex(1);

$excel->getActiveSheet()->setTitle("Business");

//populate the data
$query = mysqli_query($conn, "select * from cars");
$row = 2;
while ($data = mysqli_fetch_object($query)) {
    $excel->getActiveSheet()
        ->setCellValue('A'.$row, $data->id)
        ->setCellValue('B'.$row, $data->name)
        ->setCellValue('C'.$row, $data->year);
    //increament for row
    $row++;
}


//set column width
$excel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
$excel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
    
//make table headers
$excel->getActiveSheet()
    ->setCellValue('A1', 'ID')
    ->setCellValue('B1', 'Name')
    ->setCellValue('C1', 'Year');

//merging title cells
$excel->getActiveSheet()->getStyle('A1:C1');

//aligning
$excel->getActiveSheet()->getStyle('A1:C1')->getAlignment()->setHorizontal('center');


//styling
$excel->getActiveSheet()->getStyle('A1:C1')->applyFromArray(
    array(
        'font' => array(
            'size' => 13,
        )
    )
);

$excel->getActiveSheet()->getStyle('A1:C1')->applyFromArray(
    array(
        'font' => array(
            'bold' => 'true'
        )
    )
);

//Header background color
$excel->getActiveSheet()->getStyle('A1:C1')->getFill()
->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
->getStartColor()->setRGB('f3c385');


//redirect to browser (download) instead of saving teh result as a file
header('Content-Type: application/vnd.vnd.ms-excel');
header('Content-Disposition: attachment; filename="test.xls"');
header('Cache-Control: max-age=0');

//write the result to a file
$file = PHPExcel_IOFactory::createWriter($excel, 'Excel5');
//output to php output instead of filename
$report = $file->save('php://output');

//mail("emma.bambo@yahoo.com","Report",$report);


$to      = 'seun.bambo@outlook.com';
$subject = 'the subject';
$message = 'hello';
$headers = array(
    'From' => 'seun.bambo@cg-infotech.com',
    'Reply-To' => 'seun.bambo@cg-infotech.com',
    'X-Mailer' => 'PHP/' . phpversion()
);

mail($to, $subject, $message, $headers);




?> 