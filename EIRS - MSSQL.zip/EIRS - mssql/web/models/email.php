<?PHP
 
$to = "emma.bambo@yahoo.com";
$subject = "Your password with attachment test";
$from = "seun.bambo@gmail.com";
$headers = "From: $from\r\n";
$headers .= "MIME-Version: 1.0\r\n"
  ."Content-Type: multipart/mixed; boundary=\"1a2a3a\"";
 
$message = "If you can see this MIME than your client doesn't accept MIME types!\r\n"
  ."--1a2a3a\r\n";
 
$message .= "Content-Type: text/html; charset=\"iso-8859-1\"\r\n"
  ."Content-Transfer-Encoding: 7bit\r\n\r\n"
  ."<p>Kindly find attached below the report for the month</p>"
  ."<p>Find the attached report below</p> \r\n"
  ."--1a2a3a\r\n";
 
$file = file_get_contents("https://geoint.000webhostapp.com/data.xls");
 
$message .= "Content-Type: application/vnd.vnd.ms-excel; name=\"data.xls\"\r\n"
  ."Content-Transfer-Encoding: base64\r\n"
  ."Content-disposition: attachment; file=\"data.xls\"\r\n"
  ."\r\n"
  .chunk_split(base64_encode($file))
  ."--1a2a3a--";
 
// Send email
 
$success = mail($to,$subject,$message,$headers);
   if (!$success) {
  echo "Mail to " . $to . " failed .";
   }else {
  echo "Success : Mail was sent to " . $to ;
   }
 
?>