<?php
//error_reporting(E_ERROR | E_PARSE);
function count_users($conn){
	// Get the total number of results
	$result = sqlsrv_query($conn, "SELECT count(*) FROM taxpayer");
	return sqlsrv_get_field($result, 1, 1);

}

function lga() {
	$sql = "SELECT distinct lga as lga FROM taxpayer ORDER BY lga";
	$result = sqlsrv_query($sql);
	$lga = sqlsrv_fetch_array($result);
	return $lga;
}

function get_users_paging($conn,$page,$count_per_page) {
	$uniquelga = $_SESSION['lga'];
	$page = $_GET['page'];
	$offset = ($page) * $count_per_page;

	global $sql;
	

	if ($uniquelga == '') {
		$cond = '';
	} else {
		$cond = " WHERE lga = '$uniquelga' ";
	}

	if (empty($_POST['payertype']) && empty($_POST['lga'])) {
		$sql = "SELECT id, phone, address, uuid, name, name, lga, CONVERT(VARCHAR(10), created_at, 105) as created_at, amount, rin, taxpayertype, onlinecapture FROM taxpayer $cond ORDER BY created_at DESC";
	}elseif (isset($_POST['payertype']) && empty($_POST['lga'])) {
		$payertype = $_POST['payertype'];
		if (isset($uniquelga)) {
			
			$cond .= " AND taxpayertype = '$payertype' ";
		} else {
			$cond .= " WHERE taxpayertype = '$payertype' ";
		}
		$sql = "SELECT id, phone, address, uuid, name, name, lga, CONVERT(VARCHAR(10), created_at, 105) as created_at, amount, rin, taxpayertype, onlinecapture FROM taxpayer $cond ORDER BY created_at DESC";
	} elseif (isset($_POST['lga']) && empty($_POST['payertype'])) {
		$lga = $_POST['lga'];
		
		$cond .= " WHERE lga = '$lga' ";
		$sql = "SELECT id, phone, address, uuid, name, name, lga, CONVERT(VARCHAR(10), created_at, 105) as created_at, amount, rin, taxpayertype, onlinecapture FROM taxpayer $cond ORDER BY created_at DESC";
	} elseif (isset($_POST['lga']) && isset($_POST['payertype'])) {
		$payertype = $_POST['payertype'];
		$lga = $_POST['lga'];
		$cond .= " WHERE taxpayertype = '$payertype' AND lga = '$lga' ";
		$sql = "SELECT id, phone, address, uuid, name, name, lga, CONVERT(VARCHAR(10), created_at, 105) as created_at, amount, rin, taxpayertype, onlinecapture FROM taxpayer $cond ORDER BY created_at DESC";
	}
	//echo $count_per_page;
	
	$sql .= "         OFFSET $offset ROWS FETCH FIRST $count_per_page ROWS ONLY";
	//$sql = "select * from taxpayer";
	global $result;
	
	$result = sqlsrv_query($conn, $sql, array(), array("Scrollable" => SQLSRV_CURSOR_KEYSET));
	
	if (!$result) {
	    echo "An error occurred.\n";
	    exit;
	}
	$users = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC);
	//print_r($users);
	return $users;
	return $result;

}

function get_users($conn) {
	$result = sqlsrv_query($conn, "SELECT id, phone, address, uuid, name, name,lga, created_at, amount, rin, taxpayertype, onlinecapture from taxpayer ORDER  BY id desc");
	if (!$result) {
	    echo "An error occurred.\n";
	    exit;
	}
	$users = sqlsrv_fetch_array($result);
	
	return $users;

}

function get_user($conn,$id) {
	$result = sqlsrv_query($conn, "SELECT id, phone, address, uuid, name, name,lga, CONVERT(VARCHAR(10), created_at, 105) as created_at, amount, rin, taxpayertype, onlinecapture FROM taxpayer");
	if (!$result) {
	    echo "An error occurred.\n";
	    exit;
	}
	$user = sqlsrv_fetch_array($result);
	
	return $user;

}

function del_user($conn,$where){
	
	//$where = array("id" => $id);
	$res = sqlsrv_delete($conn, 'user_tbl', $where);	
	if ($res) {
	  //echo "Deleted successfully.";
	  $is_deleted = true;
	} else {
	  //echo "Error in input..";
	  $is_deleted = false;
	}	
	return $is_deleted ;
}

function update_user($conn,$data,$where_condition){
	//$where_condition = array('name'=>'Soeng');
	//$data = array("name" => "Kanel");

	$res = sqlsrv_update($conn, 'user_tbl', $data, $where_condition);
	if ($res) {
	  	//echo "Data is updated: $res";
		$is_updated = true;
	} else {
		 //echo "error in input.. <br />";
		 //echo sqlsrv_last_error($conn);
		$is_updated = false;
	}
	return $is_updated;
}

function qdel_user($conn){
	$sql = "delete from user_tbl where id = 3";

	 $result = sqlsrv_query($conn, $sql);
	if(!$result){
	  //echo sqlsrv_last_error($conn);
	  $is_deleted = true;
	} else {
	  //echo "Deleted successfully\n";
	  $is_deleted = false;
	}
	return is_deleted;
}
function insert_user($conn, $users){
	
	// Insert one by one
	foreach ($users as $key => $user) {
	    $res = sqlsrv_insert($conn, 'user_tbl' , $user);
	    if ($res) {
	      //echo "Inserted user: ".$user['name']." <br />";
	      $is_inserted = true;
		
	    } else {
	      echo sqlsrv_last_error($conn) . " <br />";
	      $is_inserted = false;	
	    }
	}
	return $is_inserted;
}




/*
if (isset($_POST['search'])) {
	$valueToSearch = $_POST['lga'];
    // search in all table columns
    // using concat mysql function
	$query = "SELECT distinct(lga) as lga FROM taxpayer WHERE lga LIKE '%" . $valueToSearch . "%'";
	$search_result = filterTable($query);

} else {
	$query = "SELECT distinct(lga) as lga FROM taxpayer";
	$search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
	include 'conn.php';
	$conn = sqlsrv_connect("host=esir-connect.ckrkdy50shek.eu-west-1.rds.amazonaws.com dbname=card_vault user=app_street password=appstreet");
	//$connect = mysqli_connect("localhost", "root", "", "test_db");
	$filter_Result = sqlsrv_query($conn, $query);
	return $filter_Result;
}
*/


?>
