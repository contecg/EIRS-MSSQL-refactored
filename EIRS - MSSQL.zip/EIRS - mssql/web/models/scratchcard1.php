<?php
function count_users($conn){
	// Get the total number of results
	//$result = sqlsrv_query($conn, "SELECT count(*) FROM individuals where type<>'admin'"); 
	$result = sqlsrv_query($conn, "SELECT count(*) FROM transactions");
	return sqlsrv_get_field($result, 1, 1);

}
function get_users_paging($conn,$page,$count_per_page) {
	$offset = ($page - 1) * $count_per_page;

	error_reporting(E_ERROR | E_PARSE);

	global $sql;

	if (empty($_POST['daterange']) && empty($_POST['sector']) && empty($_POST['denomination']) && empty($_POST['transactionid'])) {
		$cond = "";
		$sql = "SELECT id, taxpayerid, assetid, transactionid, to_char(created_at, 'DD-Mon-YYYY') as created_at, amount, scratchcard, settlementid, initcap(sector) as sector FROM transactions $cond ORDER  BY id DESC";
	} 
	//$sql .= "        LIMIT $count_per_page OFFSET $offset";
	echo $sql;
	$result = sqlsrv_query($conn,$sql);
	
	$users = sqlsrv_fetch_all($result);
	
	return $users;

}

function get_users($conn) {
	$result = sqlsrv_query($conn, "SELECT id, taxpayerid, assetid, transactionid,  created_at, amount, scratchcard, settlementid from transactions   ORDER  BY id desc limit 100");
	if (!$result) {
	    echo "An error occurred.\n";
	    exit;
	}
	$users = sqlsrv_fetch_all($result);
	
	return $users;

}

function get_user($conn,$id) {
	$result = sqlsrv_query($conn, "SELECT id, taxpayerid, assetid, transactionid,  created_at, amount, scratchcard, settlementid from transactions   where id=".$id);
	if (!$result) {
	    echo "An error occurred.\n";
	    exit;
	}
	$user = sqlsrv_fetch_array($result);
	
	return $user;

}

function del_user($conn,$where){
	
	//$where = array("id" => $id);
	$res = sqlsrv_delete($conn, 'user_tbl', $where);	
	if ($res) {
	  //echo "Deleted successfully.";
	  $is_deleted = true;
	} else {
	  //echo "Error in input..";
	  $is_deleted = false;
	}	
	return $is_deleted ;
}

function update_user($conn,$data,$where_condition){
	//$where_condition = array('name'=>'Soeng');
	//$data = array("name" => "Kanel");

	$res = sqlsrv_update($conn, 'user_tbl', $data, $where_condition);
	if ($res) {
	  	//echo "Data is updated: $res";
		$is_updated = true;
	} else {
		 //echo "error in input.. <br />";
		 //echo sqlsrv_last_error($conn);
		$is_updated = false;
	}
	return $is_updated;
}

function qdel_user($conn){
	$sql = "delete from user_tbl where id = 3";

	 $result = sqlsrv_query($conn, $sql);
	if(!$result){
	  //echo sqlsrv_last_error($conn);
	  $is_deleted = true;
	} else {
	  //echo "Deleted successfully\n";
	  $is_deleted = false;
	}
	return is_deleted;
}
function insert_user($conn, $users){
	/* 
	Test case
	$user1 = array(
		'name' => "Sok", 
		'age' => "24", 
		'country' => "CAMBODIA" 
		);

	$user2 = array(
		'name' => "VONGSA", 
		'age' => 30, 
		'country' => "Thailand" 
		);

	$user3 = array(
		'name' => "DUC", 
		'age' => 28, 
		'country' => "Vietname"
		);

	$users = array(
		$user1,
		$user2,
		$user3
		);

	*/
	// Insert one by one
	foreach ($users as $key => $user) {
	    $res = sqlsrv_insert($conn, 'user_tbl' , $user);
	    if ($res) {
	      //echo "Inserted user: ".$user['name']." <br />";
	      $is_inserted = true;
		
	    } else {
	      echo sqlsrv_last_error($conn) . " <br />";
	      $is_inserted = false;	
	    }
	}
	return $is_inserted;
}
?>
