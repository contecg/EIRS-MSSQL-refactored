<?php
require_once 'Classes/PHPExcel.php';
require_once 'Classes/PHPExcel/IOFactory.php';
require_once '../models/business.php';
require_once '../conn.php';


//create PHPExcel object
$excel = new PHPExcel();

$excel->setActiveSheetIndex(0);
$excel->getActiveSheet()->setTitle("Businesses");


$uniquelga = $_SESSION['lga'];
$page = $_GET['page'];
$offset = ($page) * $count_per_page;

global $sql;

//populate the data
if (empty($_POST['sector']) && empty($_POST['lga']) && empty($_POST['payerid']) && empty($uniquelga)) {
    $cond = "";
    $sql = "SELECT id, sector, subsector, lga, amount, CONVERT(VARCHAR(10), created_at, 105) as date_created, taxpayer, onlinecapture, CONVERT(VARCHAR(10), syncedonline, 105) as date_synced, individual_id, uuid   FROM businesseslga $cond ORDER  BY id DESC";
} elseif (empty($_POST['sector']) && empty($_POST['lga']) && empty($_POST['payerid']) && !empty($uniquelga)) {
    $cond = " WHERE lga = '$uniquelga'";
    $sql = "SELECT id, sector, subsector, lga, amount, CONVERT(VARCHAR(10), created_at, 105) as date_created, taxpayer, onlinecapture, CONVERT(VARCHAR(10), syncedonline, 105) as date_synced, individual_id, uuid   FROM businesseslga $cond ORDER  BY id DESC";
} elseif (isset($_POST['sector']) && empty($_POST['lga']) && empty($_POST['payerid'])) {
    $sector = ucfirst($_POST['sector']);
    $cond = " WHERE sector = '$sector' ";
    $sql = "SELECT id, sector, subsector, lga, amount, CONVERT(VARCHAR(10), created_at, 105) as date_created, taxpayer, onlinecapture, CONVERT(VARCHAR(10), syncedonline, 105) as date_synced, individual_id, uuid   FROM businesseslga $cond ORDER  BY id DESC";
} elseif (isset($_POST['lga']) && empty($_POST['sector']) && empty($_POST['payerid'])) {
    $lga = $_POST['lga'];
    $cond = " WHERE lga = '$lga' ";
    $sql = "SELECT id, sector, subsector, lga, amount, CONVERT(VARCHAR(10), created_at, 105) as date_created, taxpayer, onlinecapture, CONVERT(VARCHAR(10), syncedonline, 105) as date_synced, individual_id, uuid   FROM businesseslga $cond ORDER  BY id DESC";
} elseif (isset($_POST['payerid']) && empty($_POST['lga']) && empty($_POST['sector'])) {
    //$name = $_POST['name'];
    $payerid = $_POST['payerid'];
    $cond = " WHERE uuid = '$payerid' ";
    $sql = "SELECT id, sector, subsector, lga, amount, CONVERT(VARCHAR(10), created_at, 105) as date_created, taxpayer, onlinecapture, CONVERT(VARCHAR(10), syncedonline, 105) as date_synced, individual_id, uuid   FROM businesseslga $cond ORDER  BY id DESC";
} elseif (isset($_POST['payerid']) && isset($_POST['lga']) && empty($_POST['sector'])) {
    $payerid = $_POST['payerid'];
    $lga = $_POST['lga'];
    $cond = " WHERE uuid = '$payerid' AND lga = '$lga' ";
    $sql = "SELECT id, sector, subsector, lga, amount, CONVERT(VARCHAR(10), created_at, 105) as date_created, taxpayer, onlinecapture, CONVERT(VARCHAR(10), syncedonline, 105) as date_synced, individual_id, uuid   FROM businesseslga $cond ORDER  BY id DESC";
} elseif (isset($_POST['payerid']) && isset($_POST['sector']) && empty($_POST['lga'])) {
    $payerid = $_POST['payerid'];
    $sector = $_POST['sector'];
    $cond = " WHERE uuid = '$payerid' AND sector = '$sector' ";
    $sql = "SELECT id, sector, subsector, lga, amount, CONVERT(VARCHAR(10), created_at, 105) as date_created, taxpayer, onlinecapture, CONVERT(VARCHAR(10), syncedonline, 105) as date_synced, individual_id, uuid   FROM businesseslga $cond ORDER  BY id DESC";
} elseif (isset($_POST['lga']) && isset($_POST['sector']) && empty($_POST['payerid'])) {
    $sector = $_POST['sector'];
    $lga = $_POST['lga'];
    $cond = " WHERE sector = '$sector' AND lga = '$lga' ";
    $sql = "SELECT id, sector, subsector, lga, amount, CONVERT(VARCHAR(10), created_at, 105) as date_created, taxpayer, onlinecapture, CONVERT(VARCHAR(10), syncedonline, 105) as date_synced, individual_id, uuid   FROM businesseslga $cond ORDER  BY id DESC";
} elseif (isset($_POST['payerid']) && isset($_POST['sector']) && isset($_POST['lga'])) {
    $sector = $_POST['sector'];
    $payerid = $_POST['payerid'];
    $lga = $_POST['lga'];
    $cond = " WHERE sector = '$sector' AND uuid = '$payerid' AND lga = '$lga' ";
    $sql = "SELECT id, sector, subsector, lga, amount, CONVERT(VARCHAR(10), created_at, 105) as date_created, taxpayer, onlinecapture, CONVERT(VARCHAR(10), syncedonline, 105) as date_synced, individual_id, uuid   FROM businesseslga $cond ORDER  BY id DESC";
}
//echo $sql;
$query = sqlsrv_query($conn, $sql);
$row = 2;
while ($data = sqlsrv_fetch_object($query)) {
    $excel->getActiveSheet()
        ->setCellValue('A' . $row, $data->id)
        ->setCellValue('B' . $row, $data->sector)
        ->setCellValue('C' . $row, $data->subsector)
        ->setCellValue('D' . $row, $data->lga)
        ->setCellValue('E' . $row, $data->amount)
        ->setCellValue('F' . $row, $data->date_created)
        ->setCellValue('G' . $row, $data->taxpayertype)
        ->setCellValue('H' . $row, $data->onlinecapture)
        ->setCellValue('I' . $row, $data->date_syned);
    //increament for row
    $row++;
}

//set column width
$excel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('E')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('F')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('G')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('H')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('I')->setWidth(20);



//make table headers
$excel->getActiveSheet()
    ->setCellValue('A1', 'ID')
    ->setCellValue('B1', 'Sector')
    ->setCellValue('C1', 'Sub Sector')
    ->setCellValue('D1', 'LGA')
    ->setCellValue('E1', 'Amount')
    ->setCellValue('F1', 'Created At')
    ->setCellValue('G1', 'Payer Type')
    ->setCellValue('H1', 'Online Capture')
    ->setCellValue('I1', 'Synced Online');

//merging title cells
$excel->getActiveSheet()->getStyle('A1:I1');

//aligning
$lastrow = $excel->getActiveSheet()->getHighestRow();
$excel->getActiveSheet()->getStyle('A1:I' . $lastrow)->getAlignment()->setHorizontal('center');


//styling
$excel->getActiveSheet()->getStyle('A1:I' . $lastrow)->applyFromArray(
    array(
        'font' => array(
            'size' => 11,
            'name' => 'Arial',
        )
    )
);

$excel->getActiveSheet()->getStyle('A1:I1')->applyFromArray(
    array(
        'font' => array(
            'bold' => 'true'
        )
    )
);

//--------------------------------------------------

header('Content-Type: application/vnd.vnd.ms-excel');
header('Content-Transfer-Encoding: base64');
header('Content-disposition: attachment; filename=business.xls');
//write the result to a file
$write = PHPExcel_IOFactory::createWriter($excel, 'Excel5');
$write->save('php://output');
