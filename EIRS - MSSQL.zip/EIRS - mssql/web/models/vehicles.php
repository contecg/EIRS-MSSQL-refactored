<?php
function count_users($conn){
	// Get the total number of results

	$result = sqlsrv_query($conn, "SELECT count(*) FROM vehicleslga"); 
	return sqlsrv_get_field($result, 1, 1);

}
function get_users_paging($conn,$page,$count_per_page) {
	$uniquelga = $_SESSION['lga'];
	$page = $_GET['page'];
	$offset = ($page) * $count_per_page;
	//$sql = "SELECT x.id as id , x.vehicle_number as vehicle_number , y.id as individual_id, y.uuid as payer_id, x.created_at as created_at, x.updated_at as updated_id, x.lga as lga, x.amount as amount, x.sector as sector, x.subsector as  subsector, x.taxpayer as taxpayertype, x.onlinecapture as onlinecapture, x.syncedonline as syncedonline  from vehicles x, individuals y  where x.individual_id = y.id ORDER  BY x.id desc";

	//error_reporting(E_ERROR | E_PARSE);

	global $sql;

	if (empty($_POST['vnumber']) && empty($_POST['phone']) && empty($_POST['lga']) && empty($uniquelga)) {
		$cond = "";
		$sql = "SELECT id, vehicle_number, phone, sector, subsector, lga, amount, CONVERT(VARCHAR(10), created_at, 105) as created_at, taxpayer, onlinecapture, CONVERT(VARCHAR(10), created_at, 105) as date_synced FROM vehicleslga $cond ORDER  BY id DESC";
		} 
	elseif (empty($_POST['vnumber']) && empty($_POST['phone']) && empty($_POST['lga']) && !empty($uniquelga)) {
		$cond = " WHERE lga = '$uniquelga'";
		$sql = "SELECT id, vehicle_number, phone, sector, subsector, lga, amount, CONVERT(VARCHAR(10), created_at, 105) as created_at, taxpayer, onlinecapture, CONVERT(VARCHAR(10), created_at, 105) as date_synced FROM vehicleslga $cond ORDER  BY id DESC";
		}
	elseif (isset($_POST['lga']) && empty($_POST['vnumber']) && empty($_POST['phone']) && !empty($uniquelga)) {
		$lga = $_POST['lga'];
		$cond = " WHERE lga = '$lga' ";
		$sql = "SELECT id, vehicle_number, phone, sector, subsector, lga, amount, CONVERT(VARCHAR(10), created_at, 105) as created_at, taxpayer, onlinecapture, CONVERT(VARCHAR(10), created_at, 105) as date_synced FROM vehicleslga $cond ORDER  BY id DESC";
	} elseif (isset($_POST['vnumber']) && empty($_POST['lga']) && empty($_POST['phone'])) {
		$vnumber = $_POST['vnumber'];
		$cond = " WHERE vehicle_number LIKE '%$vnumber%' ";
		$sql = "SELECT id, vehicle_number, phone, sector, subsector, lga, amount, CONVERT(VARCHAR(10), created_at, 105) as created_at, taxpayer, onlinecapture, CONVERT(VARCHAR(10), created_at, 105) as date_synced FROM vehicleslga $cond ORDER  BY id DESC";
	} elseif (isset($_POST['phone']) && empty($_POST['vnumber']) && empty($_POST['lga'])) {
		$phone = $_POST['phone'];
		$cond = " WHERE phone LIKE '%$phone%' ";
		$sql = "SELECT id, vehicle_number, phone, sector, subsector, lga, amount, CONVERT(VARCHAR(10), created_at, 105) as created_at, taxpayer, onlinecapture, CONVERT(VARCHAR(10), created_at, 105) as date_synced FROM vehicleslga $cond ORDER  BY id DESC";
	} elseif (isset($_POST['vnumber']) && isset($_POST['phone']) && !isset($_POST['lga'])) {
		$vnumber = $_POST['vnumber'];
		$phone = $_POST['phone'];
		$cond = " WHERE vehicle_number LIKE '%$vnumber%' AND phone LIKE '%$phone%' ";
		$sql = "SELECT id, vehicle_number, phone, sector, subsector, lga, amount, CONVERT(VARCHAR(10), created_at, 105) as created_at, taxpayer, onlinecapture, CONVERT(VARCHAR(10), created_at, 105) as date_synced FROM vehicleslga $cond ORDER  BY id DESC";
	} elseif (isset($_POST['vnumber']) && isset($_POST['lga']) && empty($_POST['phone'])) {
		$vnumber = $_POST['vnumber'];
		$lga = $_POST['lga'];
		$cond = " WHERE vehicle_number LIKE '%$vnumber%' AND lga = '$lga' ";
		$sql = "SELECT id, vehicle_number, phone, sector, subsector, lga, amount, CONVERT(VARCHAR(10), created_at, 105) as created_at, taxpayer, onlinecapture, CONVERT(VARCHAR(10), created_at, 105) as date_synced FROM vehicleslga $cond ORDER  BY id DESC";
	} elseif (isset($_POST['phone']) && isset($_POST['lga']) && empty($_POST['vnumber'])) {
		$phone = $_POST['phone'];
		$lga = $_POST['lga'];
		$cond = " WHERE phone LIKE '%$phone%' AND lga LIKE '%$lga%' ";
		$sql = "SELECT id, vehicle_number, phone, sector, subsector, lga, amount, CONVERT(VARCHAR(10), created_at, 105) as created_at, taxpayer, onlinecapture, CONVERT(VARCHAR(10), created_at, 105) as date_synced FROM vehicleslga $cond ORDER  BY id DESC";
	} elseif (isset($_POST['vnumber']) || isset($_POST['phone']) || isset($_POST['lga'])) {
		$vnumber = $_POST['vnumber'];
		$phone = $_POST['phone'];
		$lga = $_POST['lga'];
		$cond = " WHERE vehicle_number LIKE '%$vnumber%' AND phone LIKE '%$phone%' AND lga = '$lga' ";
		$sql = "SELECT id, vehicle_number, phone, sector, subsector, lga, amount, CONVERT(VARCHAR(10), created_at, 105) as created_at, taxpayer, onlinecapture, CONVERT(VARCHAR(10), created_at, 105) as date_synced FROM vehicleslga $cond ORDER  BY id DESC";
	} elseif (isset($_POST['vnumber']) && isset($_POST['phone']) && isset($_POST['lga'])) {
		$vnumber = $_POST['vnumber'];
		$phone = $_POST['phone'];
		$lga = $_POST['lga'];
		$cond = " WHERE vehicle_number LIKE '%$vnumber%' AND phone LIKE '%$phone%' AND lga = '$lga' ";
		$sql = "SELECT id, vehicle_number, phone, sector, subsector, lga, amount, CONVERT(VARCHAR(10), created_at, 105) as created_at, taxpayer, onlinecapture, CONVERT(VARCHAR(10), created_at, 105) as date_synced FROM vehicleslga $cond ORDER  BY id DESC";
	}
	//echo $sql;

	$sql .= "         OFFSET $offset ROWS FETCH FIRST $count_per_page ROWS ONLY";
	//$sql = "select * from vehicleslga";
	global $result;

	$result = sqlsrv_query($conn, $sql, array(), array("Scrollable" => SQLSRV_CURSOR_KEYSET));
	if (!$result) {
		echo "An error occurred.\n";
	}
	//print_r($sql);
	$users = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC);
	return $users;
	//$count = count($users);
	return $result;

}

function get_users($conn) {
	//$result = sqlsrv_query($conn, "SELECT x.id as id , x.vehicle_number as vehicle_number , y.id as individual_id, y.uuid as payer_id, x.created_at as created_at, x.updated_at as updated_id, x.lga as lga, x.amount as amount, x.sector as sector, x.subsector as  subsector, x.taxpayer as taxpayertype  from vehicles x, individuals y  where x.individual_id = y.id ORDER  BY x.id desc  limit 100");
	
	$result = sqlsrv_query($conn, "SELECT id as id , vehicle_number as vehicle_number, phone, individual_id as individual_id, uuid as payer_id, created_at as created_at, updated_at as updated_id, lga as lga, amount as amount, sector as sector, subsector as  subsector, taxpayer as taxpayertype, onlinecapture, syncedonline      from vehicles ORDER  BY id desc  limit 100");

	
	
	if (!$result) {
	    echo "An error occurred.\n";
	    exit;
	}
	$users = sqlsrv_fetch_all($result);
	
	return $users;

}

function get_user($conn,$id) {
	
	//$result = sqlsrv_query($conn, "SELECT x.id as id , x.vehicle_number as vehicle_number , y.id as individual_id, y.uuid as payer_id, x.created_at as created_at, x.updated_at as updated_id, x.lga as lga, x.amount as amount, x.sector as sector, x.subsector as  subsector, x.taxpayer as taxpayertype  from vehicles x, individuals y  where x.individual_id = y.id and  x.id=".$id);
	
	$result = sqlsrv_query($conn, "SELECT id as id , vehicle_number as vehicle_number, phone, individual_id as individual_id, uuid as payer_id, created_at as created_at, updated_at as updated_id, lga as lga, amount as amount, sector as sector, subsector as  subsector, taxpayer as taxpayertype  from vehicles where id=".$id);
	
	
	if (!$result) {
	    echo "An error occurred.\n";
	    exit;
	}
	$user = sqlsrv_fetch_array($result);
	
	return $user;

}

?>
