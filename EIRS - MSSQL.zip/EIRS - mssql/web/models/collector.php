<?php
error_reporting(E_ERROR | E_PARSE);
//include ('controllers/login_ajax.php');
/*
function filter($conn) {
    $res = sqlsrv_query($conn, "SELECT distinct(state) as state FROM agents");
    $ress = sqlsrv_fetch_all($res);
    return $users;
    
}
*/
function count_users($conn)
{
	// Get the total number of results

    $result = sqlsrv_query($conn, "SELECT count(*) FROM collections");
    return sqlsrv_get_field($result, 1, 1);

}
function get_users_paging($conn, $page, $count_per_page)
{
    $uniquelga = $_SESSION['lga'];
    $page = $_GET['page'];
    $offset = ($page) * $count_per_page;

	//$sql = "SELECT x.id as id , x.name as name , x.address as address, y.id as individual_id, y.uuid as payer_id, x.created_at as created_at, x.updated_at as updated_id, x.lga as lga, x.amount as amount, x.sector as sector, x.subsector as  subsector, x.taxpayer as taxpayertype  from businesses x, individuals y  where x.individual_id = y.id ORDER  BY x.id desc LIMIT  $count_per_page offset $offset";

    global $sql;

    if ($uniquelga == '') {
        $cond = '';
    } else {
        $cond = " WHERE lga = '$uniquelga' ";
    }
   
   

    if (empty($_POST['name']) && empty($_POST['phone']) && empty($_POST['state']) && empty($_POST['lga']) && empty($_POST['beat_code'])) {
        
        $sql = "SELECT first_name+' '+last_name as name, phone, beat_code, address, birthplace, state, CONVERT(VARCHAR(10), created_at, 105) as created_at, CONVERT(VARCHAR(10), dob, 105) as dob, lga, amount, id, status  FROM agents $cond ORDER BY created_at DESC";
    } elseif(empty($_POST['name']) && empty($_POST['phone']) && empty($_POST['state']) && empty($_POST['lga']) && empty($_POST['beat_code'])) {
        $cond = "";
        $sql = "SELECT first_name+' '+last_name as name, phone, beat_code, address, birthplace, state, CONVERT(VARCHAR(10), created_at, 105) as created_at, CONVERT(VARCHAR(10), dob, 105) as dob, lga, amount, id, status  FROM agents $cond ORDER BY created_at DESC";
	}elseif (isset($_POST['lga']) && empty($_POST['phone']) && empty($_POST['state']) && empty($_POST['name']) && empty($_POST['beat_code'])) {
        $lga = $_POST['lga'];
        $cond = " WHERE lga = '$lga' ";
        $sql = "SELECT first_name+' '+last_name as name, phone, beat_code, address, birthplace, state, CONVERT(VARCHAR(10), created_at, 105) as created_at, CONVERT(VARCHAR(10), dob, 105) as dob, lga, amount, id, status  FROM agents $cond ORDER BY created_at DESC";
    } elseif (isset($_POST['state']) && empty($_POST['phone']) && empty($_POST['name']) && empty($_POST['lga']) && empty($_POST['beat_code'])) {
        $state = $_POST['state'];
        $cond = " WHERE state = '$state' ";
        $sql = "SELECT first_name+' '+last_name as name, phone, beat_code, address, birthplace, state, CONVERT(VARCHAR(10), created_at, 105) as created_at, CONVERT(VARCHAR(10), dob, 105) as dob, lga, amount, id, status  FROM agents $cond ORDER BY created_at DESC";
    } elseif (isset($_POST['name']) && empty($_POST['phone']) && empty($_POST['state']) && empty($_POST['lga'])  && empty($_POST['beat_code'])) {
        //$name = $_POST['name'];
        $name = sqlsrv_escape_string($conn, $_POST['name']);
        $cond = " WHERE first_name LIKE '%$name%' OR last_name LIKE '%$name%' ";
        $sql = "SELECT first_name+' '+last_name as name, phone, beat_code, address, birthplace, state, CONVERT(VARCHAR(10), created_at, 105) as created_at, CONVERT(VARCHAR(10), dob, 105) as dob, lga, amount, id, status  FROM agents $cond ORDER BY created_at DESC";
    } elseif (isset($_POST['phone']) && empty($_POST['name']) && empty($_POST['state']) && empty($_POST['lga']) && empty($_POST['beat_code'])) {
        $phone = $_POST['phone'];
        $cond = " WHERE phone LIKE '%$phone%' ";
        $sql = "SELECT first_name||' '||last_name as name, phone, beat_code,address, birthplace, state, to_char(created_at, 'D-Mon-YYYY') as created_at, to_char(dob, 'D-Mon-YYYY') as dob, lga, amount, id, status  FROM agents $cond ORDER BY created_at DESC";
    } elseif (isset($_POST['beat_code']) && empty($_POST['name']) && empty($_POST['state']) && empty($_POST['lga']) && empty($_POST['phone'])) {
        $beat_code = $_POST['beat_code'];
        $cond = " WHERE beat_code = '$beat_code' ";
        $sql = "SELECT first_name+' '+last_name as name, phone, beat_code, address, birthplace, state, CONVERT(VARCHAR(10), created_at, 105) as created_at, CONVERT(VARCHAR(10), dob, 105) as dob, lga, amount, id, status  FROM agents $cond ORDER BY created_at DESC";
    }
	elseif (isset($_POST['state']) && isset($_POST['name']) && empty($_POST['phone']) && empty($_POST['lga']) && empty($_POST['beat_code'])) {
        $state = $_POST['state'];
        $name = $_POST['name'];
        $cond = " WHERE state = '$state' AND (first_name LIKE '%$name%' OR last_name LIKE '%$name%') ";
        $sql = "SELECT first_name||' '||last_name as name, phone, beat_code,address, birthplace, state, to_char(created_at, 'D-Mon-YYYY') as created_at, to_char(dob, 'D-Mon-YYYY') as dob, lga, amount, id, status  FROM agents $cond ORDER BY created_at DESC";
    } elseif (isset($_POST['phone']) && isset($_POST['name']) && empty($_POST['state']) && empty($_POST['lga']) && empty($_POST['beat_code'])) {
        $phone = $_POST['phone'];
        $name = $_POST['name'];
        $cond = " WHERE phone LIKE '%$phone%' AND (first_name LIKE '%$name%' OR last_name LIKE '%$name%') ";
        $sql = "SELECT first_name+' '+last_name as name, phone, beat_code, address, birthplace, state, CONVERT(VARCHAR(10), created_at, 105) as created_at, CONVERT(VARCHAR(10), dob, 105) as dob, lga, amount, id, status  FROM agents $cond ORDER BY created_at DESC";
    } elseif (isset($_POST['phone']) && isset($_POST['lga']) && empty($_POST['state']) && empty($_POST['name']) && empty($_POST['beat_code'])) {
        $phone = $_POST['phone'];
        $lga = $_POST['lga'];
        $cond = " WHERE phone LIKE '%$phone%' AND lga = '$lga' ";
        $sql = "SELECT first_name+' '+last_name as name, phone, beat_code, address, birthplace, state, CONVERT(VARCHAR(10), created_at, 105) as created_at, CONVERT(VARCHAR(10), dob, 105) as dob, lga, amount, id, status  FROM agents $cond ORDER BY created_at DESC";
    } elseif (isset($_POST['name']) && isset($_POST['lga']) && empty($_POST['state']) && empty($_POST['phone']) && empty($_POST['beat_code'])) {
        $name = $_POST['name'];
        $lga = $_POST['lga'];
        $cond = " WHERE (first_name LIKE '%$name%' OR last_name LIKE '%$name%') AND lga = '$lga' ";
        $sql = "SELECT first_name||' '||last_name as name, phone, beat_code,address, birthplace, state, to_char(created_at, 'D-Mon-YYYY') as created_at, to_char(dob, 'D-Mon-YYYY') as dob, lga, amount, id, status  FROM agents $cond ORDER BY created_at DESC";
    } elseif (isset($_POST['beat_code']) && isset($_POST['state']) && empty($_POST['lga']) && empty($_POST['name']) && empty($_POST['phone'])) {
        $beat_code = $_POST['beat_code'];
        $state = $_POST['state'];
        $cond = " WHERE beat_code = '$beat_code' AND state = '$state' ";
        $sql = "SELECT first_name||' '||last_name as name, phone, beat_code,address, birthplace, state, to_char(created_at, 'D-Mon-YYYY') as created_at, to_char(dob, 'D-Mon-YYYY') as dob, lga, amount, id, status  FROM agents $cond ORDER BY created_at DESC";
    } elseif (isset($_POST['beat_code']) && isset($_POST['phone']) && empty($_POST['lga']) && empty($_POST['name']) && empty($_POST['state'])) {
        $phone = $_POST['phone'];
        $beat_code = $_POST['beat_code'];
        $cond = " WHERE phone LIKE '%$phone%' AND beat_code = '$beat_code' ";
        $sql = "SELECT first_name+' '+last_name as name, phone, beat_code, address, birthplace, state, CONVERT(VARCHAR(10), created_at, 105) as created_at, CONVERT(VARCHAR(10), dob, 105) as dob, lga, amount, id, status  FROM agents $cond ORDER BY created_at DESC";
    } elseif (isset($_POST['beat_code']) && isset($_POST['lga']) && empty($_POST['state']) && empty($_POST['name']) && empty($_POST['phone'])) {
        $beat_code = $_POST['beat_code'];
        $lga = $_POST['lga'];
        $cond = " WHERE beat_code = '$beat_code' AND lga = '$lga' ";
        $sql = "SELECT first_name+' '+last_name as name, phone, beat_code, address, birthplace, state, CONVERT(VARCHAR(10), created_at, 105) as created_at, CONVERT(VARCHAR(10), dob, 105) as dob, lga, amount, id, status  FROM agents $cond ORDER BY created_at DESC";
    } elseif (isset($_POST['beat_code']) && isset($_POST['name']) && empty($_POST['lga']) && empty($_POST['name']) && empty($_POST['phone'])) {
        $beat_code = $_POST['beat_code'];
        $name = $_POST['name'];
        $cond = " WHERE name LIKE '%$name%' AND beat_code = '$beat_code' ";
        $sql = "SELECT first_name+' '+last_name as name, phone, beat_code, address, birthplace, state, CONVERT(VARCHAR(10), created_at, 105) as created_at, CONVERT(VARCHAR(10), dob, 105) as dob, lga, amount, id, status  FROM agents $cond ORDER BY created_at DESC";
    }
	elseif (isset($_POST['name']) && isset($_POST['phone']) && isset($_POST['state']) && empty($_POST['lga']) && empty($_POST['beat_code'])) {
        $name = $_POST['name'];
        $phone = $_POST['phone'];
        $state = $_POST['state'];
        $cond = " WHERE (first_name LIKE '%$name%' OR last_name LIKE '%$name%') AND phone LIKE '%$phone%' AND state = '$state' ";
        $sql = "SELECT first_name||' '||last_name as name, phone, beat_code,address, birthplace, state, to_char(created_at, 'D-Mon-YYYY') as created_at, to_char(dob, 'D-Mon-YYYY') as dob, lga, amount, id, status  FROM agents $cond ORDER BY created_at DESC";
    } elseif (isset($_POST['name']) && isset($_POST['phone']) && isset($_POST['lga']) && empty($_POST['state'])) {
        $name = $_POST['name'];
        $phone = $_POST['phone'];
        $lga = $_POST['lga'];
        $cond = " WHERE (first_name LIKE '%$name%' OR last_name LIKE '%$name%') AND phone LIKE '%$phone%' AND lga = '$lga' ";
        $sql = "SELECT first_name+' '+last_name as name, phone, beat_code, address, birthplace, state, CONVERT(VARCHAR(10), created_at, 105) as created_at, CONVERT(VARCHAR(10), dob, 105) as dob, lga, amount, id, status  FROM agents $cond ORDER BY created_at DESC";
    } elseif (isset($_POST['name']) && isset($_POST['phone']) && isset($_POST['state']) && isset($_POST['lga'])) {
        $name = $_POST['name'];
        $phone = $_POST['phone'];
        $state = $_POST['state'];
        $lga = $_POST['lga'];
        $cond = " WHERE first_name LIKE '%$name%' AND phone LIKE '%$phone%' AND state = '$state' AND lga = '$lga' ";
        $sql = "SELECT first_name+' '+last_name as name, phone, beat_code, address, birthplace, state, CONVERT(VARCHAR(10), created_at, 105) as created_at, CONVERT(VARCHAR(10), dob, 105) as dob, lga, amount, id, status  FROM agents $cond ORDER BY created_at DESC";
    } elseif (isset($_POST['name']) && isset($_POST['phone']) && isset($_POST['state']) && isset($_POST['lga'])) {
        $name = $_POST['name'];
        $phone = $_POST['phone'];
        $state = $_POST['state'];
        $lga = $_POST['lga'];
        $cond = " WHERE first_name LIKE '%$name%' OR phone LIKE '%$phone%' OR state = '$state' OR lga = '$lga' ";
        $sql = "SELECT first_name+' '+last_name as name, phone, beat_code, address, birthplace, state, CONVERT(VARCHAR(10), created_at, 105) as created_at, CONVERT(VARCHAR(10), dob, 105) as dob, lga, amount, id, status  FROM agents $cond ORDER BY created_at DESC";
    }

    $sql .= "         OFFSET $offset ROWS FETCH FIRST $count_per_page ROWS ONLY";
    //$sql = "select * from collections";
    //echo $sql;
    global $result;
    //$result = metaphone($sql);
    $result = sqlsrv_query($conn, $sql, array(), array("Scrollable" => SQLSRV_CURSOR_KEYSET));
    
    if (!$result) {
        //print_r(sqlsrv_errors());
    }
    
    $users = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC);
    return $users;

    return $result;

}

function get_users($conn)
{
	//$result = sqlsrv_query($conn, "SELECT x.id as id , x.name as name , x.address as address, y.id as individual_id, y.uuid as payer_id, x.created_at as created_at, x.updated_at as updated_id, x.lga as lga, x.amount as amount, x.sector as sector, x.subsector as  subsector, x.taxpayer as taxpayertype, onlinecapture, syncedonline  from businesses x, individuals y  where x.individual_id = y.id ORDER  BY x.id desc  limit 100");

    $result = sqlsrv_query($conn, "SELECT x.id as id , x.name as name , x.address as address, x.individual_id as individual_id, x.uuid as payer_id, x.created_at as created_at, x.updated_at as updated_id, x.lga as lga, x.amount as amount, x.sector as sector, x.subsector as  subsector, x.taxpayer as taxpayertype, x.onlinecapture, x.syncedonline  from businesses x ORDER  BY x.id desc  limit 100");
	
	

    if (!$result) {
        echo "An error occurred.\n";
        exit;
    }
    $users = sqlsrv_fetch_all($result);

    return $users;

}

function get_user($conn, $id)
{
	//$result = sqlsrv_query($conn, "SELECT x.id as id , x.name as name , x.address as address, x.id as individual_id, y.uuid as payer_id, x.created_at as created_at, x.updated_at as updated_id, x.lga as lga, x.amount as amount, x.sector as sector, x.subsector as  subsector, x.taxpayer as taxpayertype  from businesses x, individuals y  where x.individual_id = y.id and  x.id=".$id);

    $result = sqlsrv_query($conn, "SELECT x.first_name, x.last_name, x.phone, x.address, x.birthplace, x.state, CONVERT(VARCHAR(10), x.created_at, 105) as created_at, CONVERT(VARCHAR(10), x.dob, 105) as dob, x.lga as lga, y.amount as amount, x.id, x.status, x.beat_code,y.transactionid FROM agents x left join transactions y on cast(x.id as varchar) = y.agent_id where x.id=" . $id);
	
	//echo "SELECT x.id as id , x.name as name , x.address as address, y.id as individual_id, y.uuid as payer_id, x.created_at as created_at, x.updated_at as updated_id, x.lga as lga, x.amount as amount, x.sector as sector, x.subsector as  subsector  from businesses x, individuals y  where x.individual_id = y.id and  x.id=".$id;

    if (!$result) {
        echo sqlsrv_errors();
        exit;
    }
    $user = sqlsrv_fetch_array($result);
     
    return $user;

}


function get_user1($conn, $id)
{
	global $sql1;
	//$result = sqlsrv_query($conn, "SELECT x.id as id , x.name as name , x.address as address, x.id as individual_id, y.uuid as payer_id, x.created_at as created_at, x.updated_at as updated_id, x.lga as lga, x.amount as amount, x.sector as sector, x.subsector as  subsector, x.taxpayer as taxpayertype  from businesses x, individuals y  where x.individual_id = y.id and  x.id=".$id);

    $res = sqlsrv_query($conn, "SELECT x.first_name, x.last_name, x.phone, x.address, x.birthplace, x.state, CONVERT(VARCHAR(10), x.created_at, 105) as created_at, CONVERT(VARCHAR(10), x.dob, 105) as dob, x.lga as lga, y.amount as amount, x.id, x.status, x.beat_code,y.transactionid FROM agents x left join transactions y on cast(x.id as varchar) = y.agent_id where x.id=" . $id. "order by y.created_at desc");
	
	//echo "SELECT x.id as id , x.name as name , x.address as address, y.id as individual_id, y.uuid as payer_id, x.created_at as created_at, x.updated_at as updated_id, x.lga as lga, x.amount as amount, x.sector as sector, x.subsector as  subsector  from businesses x, individuals y  where x.individual_id = y.id and  x.id=".$id;

	$sql1 = "SELECT distinct x.first_name, x.last_name from agents x where x.id=" . $id;

	
    if (!$res) {
        echo "An error occurred.\n";
        exit;
    }
    $user1 = sqlsrv_fetch_array($res);
     
    return $user1;
    return $res;

}



function del_user($conn, $where)
{
	
	//$where = array("id" => $id);
    $res = sqlsrv_delete($conn, 'user_tbl', $where);
    if ($res) {
	  //echo "Deleted successfully.";
        $is_deleted = true;
    } else {
	  //echo "Error in input..";
        $is_deleted = false;
    }
    return $is_deleted;
}

function update_user($conn, $data, $where_condition)
{
	//$where_condition = array('name'=>'Soeng');
	//$data = array("name" => "Kanel");

    $res = sqlsrv_update($conn, 'user_tbl', $data, $where_condition);
    if ($res) {
	  	//echo "Data is updated: $res";
        $is_updated = true;
    } else {
		 //echo "error in input.. <br />";
		 //echo sqlsrv_last_error($conn);
        $is_updated = false;
    }
    return $is_updated;
}

function qdel_user($conn)
{
    $sql = "delete from user_tbl where id = 3";

    $result = sqlsrv_query($conn, $sql);
    if (!$result) {
	  //echo sqlsrv_last_error($conn);
        $is_deleted = true;
    } else {
	  //echo "Deleted successfully\n";
        $is_deleted = false;
    }
    return $is_deleted;
}
function insert_user($conn, $users)
{
	/* 
	Test case
	$user1 = array(
		'name' => "Sok", 
		'age' => "24", 
		'country' => "CAMBODIA" 
		);

	$user2 = array(
		'name' => "VONGSA", 
		'age' => 30, 
		'country' => "Thailand" 
		);

	$user3 = array(
		'name' => "DUC", 
		'age' => 28, 
		'country' => "Vietname"
		);

	$users = array(
		$user1,
		$user2,
		$user3
		);

     */
	// Insert one by one
    foreach ($users as $key => $user) {
        $res = sqlsrv_query($conn, 'user_tbl', $user);
        if ($res) {
	      //echo "Inserted user: ".$user['name']." <br />";
            $is_inserted = true;

        } else {
            echo sqlsrv_last_error($conn) . " <br />";
            $is_inserted = false;
        }
    }
    return $is_inserted;
}

