<?php
require_once 'Classes/PHPExcel.php';
require_once 'Classes/PHPExcel/IOFactory.php';
require_once '../models/taxpayers.php';

//database connection
$conn = pg_connect("host=esir-connect.ckrkdy50shek.eu-west-1.rds.amazonaws.com dbname=card_vault user=app_street password=appstreet");


//create PHPExcel object
$excel = new PHPExcel();

$excel->setActiveSheetIndex(0);
$excel->getActiveSheet()->setTitle("Scratch Card");

//populate the data
if (empty($_POST['daterange']) && empty($_POST['sector']) && empty($_POST['denomination'])) {
    $cond = "";
    $sql = "SELECT id, taxpayerid, assetid, transactionid, to_char(created_at, 'DD-Mon-YYYY') as created_at, amount, scratchcard, settlementid, initcap(sector) as sector FROM transactions $cond ORDER  BY id DESC";
} elseif (isset($_POST['sector']) && empty($_POST['denomination']) || empty($_POST['daterange'])) {
    $sector = $_POST['sector'];
    $cond = " WHERE sector = '$sector' ";
    $sql = "SELECT id, taxpayerid, assetid, transactionid,  to_char(created_at, 'DD-Mon-YYYY') as created_at, amount, scratchcard, settlementid, initcap(sector) as sector FROM transactions $cond ORDER  BY id DESC";
} elseif (isset($_POST['denomination']) && empty($_POST['sector']) || empty($_POST['daterange'])) {
    $denomination = $_POST['denomination'];
    $cond = " WHERE amount = '$denomination' ";
    $sql = "SELECT id, taxpayerid, assetid, transactionid,  to_char(created_at, 'DD-Mon-YYYY') as created_at, amount, scratchcard, settlementid, initcap(sector) as sector FROM transactions $cond ORDER  BY id DESC";
} elseif (isset($_POST['daterange']) && empty($_POST['denomination']) || empty($_POST['sector'])) {
    $daterange = $_POST['daterange'];
    $daterange = str_replace(" - ", "' AND '", $daterange);
    $cond = " WHERE created_at BETWEEN '$daterange' ";
    $sql = "SELECT id, taxpayerid, assetid, transactionid,  to_char(created_at, 'DD-Mon-YYYY') as created_at, amount, scratchcard, settlementid, initcap(sector) as sector FROM transactions $cond ORDER  BY id DESC";
} elseif (isset($_POST['denomination']) && isset($_POST['sector']) || !isset($_POST['daterange'])) {
    $sector = $_POST['sector'];
    $denomination = $_POST['denomination'];
    $cond = " WHERE  amount = '$denomination' AND sector = '$sector' ";
    $sql = "SELECT id, taxpayerid, assetid, transactionid,  to_char(created_at, 'DD-Mon-YYYY') as created_at, amount, scratchcard, settlementid, initcap(sector) as sector FROM transactions $cond ORDER  BY id DESC";
} elseif (isset($_POST['daterange']) && isset($_POST['denomination']) && empty($_POST['sector'])) {
    $daterange = $_POST['daterange'];
    $daterange = str_replace(" - ", "' AND '", $daterange);
    $denomination = $_POST['denomination'];
    $cond = " WHERE created_at BETWEEN '$daterange' AND amount = '$denomination' ";
    $sql = "SELECT id, taxpayerid, assetid, transactionid,  to_char(created_at, 'DD-Mon-YYYY') as created_at, amount, scratchcard, settlementid, initcap(sector) as sector FROM transactions $cond ORDER  BY id DESC";
} elseif (isset($_POST['daterange']) && isset($_POST['sector']) && empty($_POST['denomination'])) {
    $daterange = $_POST['daterange'];
    $daterange = str_replace(" - ", "' AND '", $daterange);
    $sector = $_POST['sector'];
    $cond = " WHERE created_at BETWEEN '$daterange' AND sector = '$sector' ";
    $sql = "SELECT id, taxpayerid, assetid, transactionid,  to_char(created_at, 'DD-Mon-YYYY') as created_at, amount, scratchcard, settlementid, initcap(sector) as sector FROM transactions $cond ORDER  BY id DESC";
} elseif (isset($_POST['daterange']) || isset($_POST['denomination']) || isset($_POST['sector'])) {
    $daterange = $_POST['daterange'];
    $daterange = str_replace(" - ", "' AND '", $daterange);
    $sector = $_POST['sector'];
    $denomination = $_POST['denomination'];
    $cond = " WHERE created_at BETWEEN '$daterange' AND sector = '$sector' AND amount = '$denomination' ";
    $sql = "SELECT id, taxpayerid, assetid, transactionid,  to_char(created_at, 'DD-Mon-YYYY') as created_at, amount, scratchcard, settlementid, initcap(sector) as sector FROM transactions $cond ORDER  BY id DESC";
} elseif (isset($_POST['daterange']) && isset($_POST['denomination']) && isset($_POST['sector'])) {
    $daterange = $_POST['daterange'];
    $daterange = str_replace(" - ", "' AND '", $daterange);
    $sector = $_POST['sector'];
    $denomination = $_POST['denomination'];
    $cond = " WHERE created_at BETWEEN '$daterange' AND sector = '$sector' AND amount = '$denomination' ";
    $sql = "SELECT id, taxpayerid, assetid, transactionid,  to_char(created_at, 'DD-Mon-YYYY') as created_at, amount, scratchcard, settlementid, initcap(sector) as sector FROM transactions $cond ORDER  BY id DESC";
}
    //echo $sql;
$query = pg_query($sql);
$row = 2;
while ($data = pg_fetch_object($query)) {
    $excel->getActiveSheet()
        ->setCellValue('A' . $row, $data->id)
        ->setCellValue('B' . $row, $data->assetid)
        ->setCellValue('C' . $row, $data->transactionid)
        ->setCellValue('D' . $row, $data->created_at)
        ->setCellValue('E' . $row, $data->amount)
        ->setCellValue('F' . $row, $data->scratchcard)
        ->setCellValue('G' . $row, $data->settlementid)
        ->setCellValue('H' . $row, $data->sector);
    //increament for row
    $row++;
}

//set column width
$excel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('E')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('F')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('G')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('H')->setWidth(20);


    
//make table headers
$excel->getActiveSheet()
    ->setCellValue('A1', 'ID')
    ->setCellValue('B1', 'Asset ID')
    ->setCellValue('C1', 'Transaction ID')
    ->setCellValue('D1', 'Transaction Date')
    ->setCellValue('E1', 'Amount')
    ->setCellValue('F1', 'Scratch Card')
    ->setCellValue('G1', 'Settlement')
    ->setCellValue('H1', 'Sector');

//merging title cells
$excel->getActiveSheet()->getStyle('A1:H1');

//aligning
$lastrow = $excel->getActiveSheet()->getHighestRow();
$excel->getActiveSheet()->getStyle('A1:H' . $lastrow)->getAlignment()->setHorizontal('center');


//styling
$excel->getActiveSheet()->getStyle('A1:H' . $lastrow)->applyFromArray(
    array(
        'font' => array(
            'size' => 11,
            'name' => 'Arial',
        )
    )
);

$excel->getActiveSheet()->getStyle('A1:H1')->applyFromArray(
    array(
        'font' => array(
            'bold' => 'true'
        )
    )
);

//--------------------------------------------------

header('Content-Type: application/vnd.vnd.ms-excel');
header('Content-Transfer-Encoding: base64');
header('Content-disposition: attachment; filename=scratchcard.xls');
//write the result to a file
$write = PHPExcel_IOFactory::createWriter($excel, 'Excel5');
$write->save('php://output');



