<?php
include_once('conn.php');
function count_users($conn)
{
	// Get the total number of results
    $result = pg_query($conn, "SELECT count(*) FROM user_tbl where type<>'admin'");
    return (int)pg_fetch_result($result, 0, 0);

}
function get_users_paging($conn, $page, $count_per_page)
{
    $offset = ($page - 1) * $count_per_page;

    $sql = "SELECT * from user_tbl where type<>'admin' ORDER  BY username LIMIT  $count_per_page offset $offset";

    $result = pg_query($conn, $sql);
    if (!$result) {
        echo "An error occurred.\n";
        exit;
    }
    $users = pg_fetch_all($result);

    return $users;

}

function get_users($conn)
{
    $result = pg_query($conn, "SELECT * FROM user_tbl");
    if (!$result) {
        echo "An error occurred.\n";
        exit;
    }
    $users = pg_fetch_all($result);

    return $users;

}

function get_user($conn, $id)
{
    $result = pg_query($conn, "SELECT * FROM user_tbl where id=" . $id);
    if (!$result) {
        echo "An error occurred.\n";
        exit;
    }
    $user = pg_fetch_array($result);

    return $user;

}

function del_user($conn, $where)
{
	
	//$where = array("id" => $id);
    $res = pg_delete($conn, 'user_tbl', $where);
    if ($res) {
	  //echo "Deleted successfully.";
        $is_deleted = true;
    } else {
	  //echo "Error in input..";
        $is_deleted = false;
    }
    return $is_deleted;
}

function update_agent($conn, $data, $where_condition)
{
	//$where_condition = array('name'=>'Soeng');
	//$data = array("name" => "Kanel");

    $res = pg_update($conn, 'agents', $data, $where_condition);
    if ($res) {
	  	//echo "Data is updated: $res";
        $is_updated = true;
    } else {
		 //echo "error in input.. <br />";
		 //echo pg_last_error($conn);
        $is_updated = false;
    }
    return $is_updated;
}

function qdel_user($conn)
{
    $sql = "delete from user_tbl where id = 3";

    $result = pg_query($conn, $sql);
    if (!$result) {
	  //echo pg_last_error($conn);
        $is_deleted = true;
    } else {
	  //echo "Deleted successfully\n";
        $is_deleted = false;
    }
    return $is_deleted;
}
function insert_user()
{
    error_reporting(E_ERROR | E_PARSE);
	global $users;
	
          if (isset($_POST['phone'])) {
              
          
            $phone = $_POST['phone'];
            $firstname = $_POST['firstname'];
            $lastname = $_POST['lastname'];
            $address = $_POST['address'];
            $birthplace = $_POST['birthplace'];
            $state = $_POST['state'];
            $lga = $_POST['lga'];
            $revenuebeat = $_POST['revenuebeat'];

    }
    $users = "INSERT INTO agents (phone, first_name, last_name, address, birthplace, state, lga, beat_code, created_at, updated_at, status) 
          VALUES ('$phone', '$firstname', '$lastname', '$address', '$birthplace', '$state', '$lga', '$revenuebeat', now(), now(), 'A')";

    

        $res = pg_insert($conn, 'agents', $users);
            }
            //echo $user;
    //return $is_inserted;
//}
//}
?>
