<?php
require_once 'Classes/PHPExcel.php';
require_once 'Classes/PHPExcel/IOFactory.php';
//require_once '../models/taxpayers.php';

//database connection
$conn = pg_connect("host=esir-connect.ckrkdy50shek.eu-west-1.rds.amazonaws.com dbname=card_vault user=app_street password=appstreet");


//create PHPExcel object
$excel = new PHPExcel();

$excel->setActiveSheetIndex(0);
$excel->getActiveSheet()->setTitle("Vehicles");

//populate the data
if (empty($_POST['vnumber']) && empty($_POST['phone']) && empty($_POST['lga'])) {
    $cond = "";
    $sql = "SELECT id as id , vehicle_number as vehicle_number, phone, individual_id as individual_id, uuid as payer_id, to_char(created_at, 'DD-Mon-YYYY') as created_at, updated_at as updated_id, lga as lga, amount as amount, initcap(sector) as sector, initcap(subsector) as  subsector, taxpayer as taxpayertype, onlinecapture, to_char(syncedonline, 'DD-Mon-YYYY') as syncedonline FROM vehicles $cond ORDER  BY id DESC";
} elseif (isset($_POST['lga']) && empty($_POST['vnumber']) && empty($_POST['phone'])) {
    $lga = $_POST['lga'];
    $cond = " WHERE lga = '$lga' ";
    $sql = "SELECT id as id, vehicle_number as vehicle_number, phone, individual_id as individual_id, uuid as payer_id, to_char(created_at, 'DD-Mon-YYYY') as created_at, updated_at as updated_id, lga as lga, amount as amount, initcap(sector) as sector, initcap(subsector) as  subsector, taxpayer as taxpayertype, onlinecapture, to_char(syncedonline, 'DD-Mon-YYYY') as syncedonline FROM vehicles $cond ORDER  BY id DESC";
} elseif (isset($_POST['vnumber']) && empty($_POST['lga']) && empty($_POST['phone'])) {
    $vnumber = $_POST['vnumber'];
    $cond = " WHERE vehicle_number LIKE '%$vnumber%' ";
    $sql = "SELECT id as id, vehicle_number as vehicle_number, phone, individual_id as individual_id, uuid as payer_id, to_char(created_at, 'DD-Mon-YYYY') as created_at, updated_at as updated_id, lga as lga, amount as amount, initcap(sector) as sector, initcap(subsector) as  subsector, taxpayer as taxpayertype, onlinecapture, to_char(syncedonline, 'DD-Mon-YYYY') as syncedonline FROM vehicles $cond ORDER  BY id DESC";
} elseif (isset($_POST['phone']) && empty($_POST['vnumber']) && empty($_POST['lga'])) {
    $phone = $_POST['phone'];
    $cond = " WHERE phone LIKE '%$phone%' ";
    $sql = "SELECT id as id, vehicle_number as vehicle_number, phone, individual_id as individual_id, uuid as payer_id, to_char(created_at, 'DD-Mon-YYYY') as created_at, updated_at as updated_id, lga as lga, amount as amount, initcap(sector) as sector, initcap(subsector) as  subsector, taxpayer as taxpayertype, onlinecapture, to_char(syncedonline, 'DD-Mon-YYYY') as syncedonline FROM vehicles $cond ORDER  BY id DESC";
} elseif (isset($_POST['vnumber']) && isset($_POST['phone']) && !isset($_POST['lga'])) {
    $vnumber = $_POST['vnumber'];
    $phone = $_POST['phone'];
    $cond = " WHERE vehicle_number LIKE '%$vnumber%' AND phone LIKE '%$phone%' ";
    $sql = "SELECT id as id, vehicle_number as vehicle_number, phone, individual_id as individual_id, uuid as payer_id, to_char(created_at, 'DD-Mon-YYYY') as created_at, updated_at as updated_id, lga as lga, amount as amount, initcap(sector) as sector, initcap(subsector) as  subsector, taxpayer as taxpayertype, onlinecapture, to_char(syncedonline, 'DD-Mon-YYYY') as syncedonline FROM vehicles $cond ORDER  BY id DESC";
} elseif (isset($_POST['vnumber']) && isset($_POST['lga']) && empty($_POST['phone'])) {
    $vnumber = $_POST['vnumber'];
    $lga = $_POST['lga'];
    $cond = " WHERE vehicle_number LIKE '%$vnumber%' AND lga = '$lga' ";
    $sql = "SELECT id as id, vehicle_number as vehicle_number, phone, individual_id as individual_id, uuid as payer_id, to_char(created_at, 'DD-Mon-YYYY') as created_at, updated_at as updated_id, lga as lga, amount as amount, initcap(sector) as sector, initcap(subsector) as  subsector, taxpayer as taxpayertype, onlinecapture, to_char(syncedonline, 'DD-Mon-YYYY') as syncedonline FROM vehicles $cond ORDER  BY id DESC";
} elseif (isset($_POST['phone']) && isset($_POST['lga']) && empty($_POST['vnumber'])) {
    $phone = $_POST['phone'];
    $lga = $_POST['lga'];
    $cond = " WHERE phone LIKE '%$phone%' AND lga LIKE '%$lga%' ";
    $sql = "SELECT id as id, vehicle_number as vehicle_number, phone, individual_id as individual_id, uuid as payer_id, to_char(created_at, 'DD-Mon-YYYY') as created_at, updated_at as updated_id, lga as lga, amount as amount, initcap(sector) as sector, initcap(subsector) as  subsector, taxpayer as taxpayertype, onlinecapture, to_char(syncedonline, 'DD-Mon-YYYY') as syncedonline FROM vehicles $cond ORDER  BY id DESC";
} elseif (isset($_POST['vnumber']) || isset($_POST['phone']) || isset($_POST['lga'])) {
    $vnumber = $_POST['vnumber'];
    $phone = $_POST['phone'];
    $lga = $_POST['lga'];
    $cond = " WHERE vehicle_number LIKE '%$vnumber%' AND phone LIKE '%$phone%' AND lga = '$lga' ";
    $sql = "SELECT id as id, vehicle_number as vehicle_number, phone, individual_id as individual_id, uuid as payer_id, to_char(created_at, 'DD-Mon-YYYY') as created_at, updated_at as updated_id, lga as lga, amount as amount, initcap(sector) as sector, initcap(subsector) as  subsector, taxpayer as taxpayertype, onlinecapture, to_char(syncedonline, 'DD-Mon-YYYY') as syncedonline FROM vehicles $cond ORDER  BY id DESC";
} elseif (isset($_POST['vnumber']) && isset($_POST['phone']) && isset($_POST['lga'])) {
    $vnumber = $_POST['vnumber'];
    $phone = $_POST['phone'];
    $lga = $_POST['lga'];
    $cond = " WHERE vehicle_number LIKE '%$vnumber%' AND phone LIKE '%$phone%' AND lga = '$lga' ";
    $sql = "SELECT id as id, vehicle_number as vehicle_number, phone, individual_id as individual_id, uuid as payer_id, to_char(created_at, 'DD-Mon-YYYY') as created_at, updated_at as updated_id, lga as lga, amount as amount, initcap(sector) as sector, initcap(subsector) as  subsector, taxpayer as taxpayertype, onlinecapture, to_char(syncedonline, 'DD-Mon-YYYY') as syncedonline FROM vehicles $cond ORDER  BY id DESC";
} 
    //echo $sql;
$query = pg_query($sql);
$row = 2;
while ($data = pg_fetch_object($query)) {
    $excel->getActiveSheet()
        ->setCellValue('A' . $row, $data->id)
        ->setCellValue('B' . $row, $data->vehicle_number)
        ->setCellValue('C' . $row, $data->phone)
        ->setCellValue('D' . $row, $data->sector)
        ->setCellValue('E' . $row, $data->subsector)
        ->setCellValue('F' . $row, $data->lga)
        ->setCellValue('G' . $row, $data->amount)
        ->setCellValue('H' . $row, $data->created_at)
        ->setCellValue('I' . $row, $data->taxpayertype)
        ->setCellValue('J' . $row, $data->onlinecapture)
        ->setCellValue('K' . $row, $data->syncedonline);
    //increament for row
    $row++;
}

//set column width
$excel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('E')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('F')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('G')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('H')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('I')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('J')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('K')->setWidth(20);


    
//make table headers
$excel->getActiveSheet()
    ->setCellValue('A1', 'ID')
    ->setCellValue('B1', 'Vehicle Number')
    ->setCellValue('C1', 'Phone')
    ->setCellValue('D1', 'Sector')
    ->setCellValue('E1', 'Sub Sector')
    ->setCellValue('F1', 'LGA')
    ->setCellValue('G1', 'Amount')
    ->setCellValue('H1', 'Created At')
    ->setCellValue('I1', 'Tax Payer Type')
    ->setCellValue('J1', 'Online Capture')
    ->setCellValue('K1', 'Synced Online');

//merging title cells
$excel->getActiveSheet()->getStyle('A1:K1');

//aligning
$lastrow = $excel->getActiveSheet()->getHighestRow();
$excel->getActiveSheet()->getStyle('A1:K' . $lastrow)->getAlignment()->setHorizontal('center');


//styling
$excel->getActiveSheet()->getStyle('A1:K' . $lastrow)->applyFromArray(
    array(
        'font' => array(
            'size' => 11,
            'name' => 'Arial',
        )
    )
);

$excel->getActiveSheet()->getStyle('A1:K1')->applyFromArray(
    array(
        'font' => array(
            'bold' => 'true'
        )
    )
);

//--------------------------------------------------


header('Content-Type: application/vnd.vnd.ms-excel');
header('Content-Transfer-Encoding: base64');
header('Content-disposition: attachment; filename=vehicle.xls');
//write the result to a file
$write = PHPExcel_IOFactory::createWriter($excel, 'Excel5');
$write->save('php://output');



