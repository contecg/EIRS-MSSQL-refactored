<?php
require_once 'Classes/PHPExcel.php';
require_once 'Classes/PHPExcel/IOFactory.php';
require_once '../models/taxpayers.php';
require_once '../conn.php';



//create PHPExcel object
$excel = new PHPExcel();

$excel->setActiveSheetIndex(0);
$excel->getActiveSheet()->setTitle("Taxpayers");

//populate the data
if (empty($_POST['payertype']) && empty($_POST['lga'])) {
    $sql = "SELECT id, phone, address, uuid, name, name, lga, CONVERT(VARCHAR(10), created_at, 105) as created_at, amount, rin, taxpayertype, onlinecapture FROM taxpayer where phone = '2347033334239' ORDER BY created_at DESC";
} elseif (isset($_POST['payertype']) && empty($_POST['lga'])) {
    $payertype = $_POST['payertype'];
    if (isset($uniquelga)) {

        $cond .= " AND taxpayertype = '$payertype' ";
    } else {
        $cond .= " WHERE taxpayertype = '$payertype' ";
    }
    $sql = "SELECT id, phone, address, uuid, name, name, lga, CONVERT(VARCHAR(10), created_at, 105) as created_at, amount, rin, taxpayertype, onlinecapture FROM taxpayer $cond ORDER BY created_at DESC";
} elseif (isset($_POST['lga']) && empty($_POST['payertype'])) {
    $lga = $_POST['lga'];
    $cond .= " WHERE lga = '$lga' ";
    $sql = "SELECT id, phone, address, uuid, name, name, lga, CONVERT(VARCHAR(10), created_at, 105) as created_at, amount, rin, taxpayertype, onlinecapture FROM taxpayer $cond ORDER BY created_at DESC";
} elseif (isset($_POST['lga']) && isset($_POST['payertype'])) {
    $payertype = $_POST['payertype'];
    $lga = $_POST['lga'];
    $cond .= " WHERE taxpayertype = '$payertype' AND lga = '$lga' ";
    $sql = "SELECT id, phone, address, uuid, name, name, lga, CONVERT(VARCHAR(10), created_at, 105) as created_at, amount, rin, taxpayertype, onlinecapture FROM taxpayer $cond ORDER BY created_at DESC";
}

$query = sqlsrv_query($conn, $sql);

$row = 2;
while ($data = sqlsrv_fetch_object($query)) {
    $excel->getActiveSheet()
        ->setCellValue('A' . $row, $data->id)
        ->setCellValue('B' . $row, $data->phone)
        ->setCellValue('C' . $row, $data->address)
        ->setCellValue('D' . $row, $data->uuid)
        ->setCellValue('E' . $row, $data->name)
        ->setCellValue('F' . $row, $data->lga)
        ->setCellValue('G' . $row, $data->created_at)
        ->setCellValue('H' . $row, $data->amount)
        ->setCellValue('I' . $row, $data->rin)
        ->setCellValue('J' . $row, $data->taxpayertype)
        ->setCellValue('K' . $row, $data->onlinecapture);
    //increament for row
    $row++;
}

//set column width
$excel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('E')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('F')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('G')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('H')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('I')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('J')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('K')->setWidth(20);


    
//make table headers
$excel->getActiveSheet()
    ->setCellValue('A1', 'ID')
    ->setCellValue('B1', 'Phone')
    ->setCellValue('C1', 'Address')
    ->setCellValue('D1', 'UUID')
    ->setCellValue('E1', 'Name')
    ->setCellValue('F1', 'LGA')
    ->setCellValue('G1', 'Created At')
    ->setCellValue('H1', 'Amount')
    ->setCellValue('I1', 'RIN')
    ->setCellValue('J1', 'Tax Payer Type')
    ->setCellValue('K1', 'Online Capture');

//merging title cells
$excel->getActiveSheet()->getStyle('A1:K1');

//aligning
$lastrow = $excel->getActiveSheet()->getHighestRow();
$excel->getActiveSheet()->getStyle('A1:K' . $lastrow)->getAlignment()->setHorizontal('center');


//styling
$excel->getActiveSheet()->getStyle('A1:K' . $lastrow)->applyFromArray(
    array(
        'font' => array(
            'size' => 11,
            'name' => 'Arial',
        )
    )
);

$excel->getActiveSheet()->getStyle('A1:K1')->applyFromArray(
    array(
        'font' => array(
            'bold' => 'true'
        )
    )
);

//--------------------------------------------------

$file = "ESIRconnect" . date('Y-m-d H-i-s') . ".xls";
$dir = 'myDir';


if (!file_exists($dir)) {
    mkdir($dir, 0744);
}


header('Content-Type: application/vnd.vnd.ms-excel');
header('Content-Transfer-Encoding: base64');
header('Content-disposition: attachment; filename=' . $file);
//write the result to a file
$write = PHPExcel_IOFactory::createWriter($excel, 'Excel5');
$write->save('php://output');



