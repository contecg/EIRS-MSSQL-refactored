<?php

include_once('conn.php');
include_once('models/collector.php');

    if (isset($_POST['id'])) {
        

        echo "<script type='text/javascript'>
            confirm('You are changing the status of user');
        </script>";

        $id = $_POST['id'];

        $status = $user['status'];

        /*
        echo $q . "<br>";
        echo $status . "<br>";
        echo $id . "<br>";
        */

        if ($status == 'D') {
            $q = "UPDATE agents SET status = 'A', disabled_date = getdate() WHERE id = $id";
            } elseif ($status == 'A') {
            $q = "UPDATE agents SET status = 'D', disabled_date = getdate() WHERE id = $id";
            }
            
            
        sqlsrv_query($conn, $q);
            
    header('location: index.php?controller=collectors');

    //include_once('views/list_collector.php');
    }