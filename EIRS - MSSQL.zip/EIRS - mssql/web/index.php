<?php
//echo $_GET['controller'];
//https://github.com/skanel/crud-php-postgres
if (isset($_GET['controller']) ) {
	error_reporting(E_ERROR | E_PARSE);
	include_once('conn.php');
	session_start();
	include_once('lib/helper.php');	
	require_once('controllers/'.$_GET['controller'].".php");
	//require_once('controllers/individuals.php');
	// Close the connection
	sqlsrv_close($conn);	
	
}else{
	require_once('controllers/login.php');		
}

?>
